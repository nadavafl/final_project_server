import { Router } from "express";
import {
  IAdvertising,
  IAdvertisingInput,
  IContactInfo,
  IImage,  
} from "../db/types/db";
import { advertisingService } from "../service/advertising.service";
import { verifyRegisteredUser } from "../middleware/verify-registeredUser";
import {
  validateContactInfo,
  validateUploadAd,
} from "../middleware/validate-schema";
import { verifyAdmin } from "../middleware/verify-admin";
import { upload } from "../helpers/memoryStorage";

const router = Router();

//Post ad
router.post(
  "/:id",
  verifyRegisteredUser,
  validateUploadAd,
  upload.single("file"),
  async (req, res, next) => {
    try {
      const userId = req.params.id;
      const body = req.body;
      const file = req.file;
      if (!file) {
        res.json({
          status: 400,
          message: "You must provide a file",
        });
      } else {
        let contactInfo = JSON.parse(body.contactInfo);
        const imageUploadObject = <IImage>{
          file: {
            data: file?.buffer,
            contentType: file?.mimetype,
          },
          fileName: body.fileName,
        };
        let advertisingUploadObject: any = {
          images: imageUploadObject,
          linkTo: body.linkTo,
          contactInfo: {
            name: contactInfo.name,
            phone: contactInfo.phone,
            email: contactInfo.email,
          },
          createdByUser_id: userId,
        };

        const uploadedFile = await advertisingService.postAd(
          userId,
          advertisingUploadObject,
          imageUploadObject
        );
        res.json({ status: 200, message: uploadedFile });
      }
    } catch (error) {
      next(error);
    }
  }
);

// Delete image from ad
router.delete("/:id/:fileId", verifyAdmin, async (req, res, next) => {
  try {
    const adId = req.params.id;
    const fileId = req.params.fileId;
    const deletedAd = await advertisingService.deleteImgAd(adId, fileId);
    res.json({ status: 200, message: deletedAd });
  } catch (error) {
    next(error);
  }
});

// Click ad
router.patch("/:id", verifyRegisteredUser, async (req, res, next) => {
  try {
    const adId = req.params.id;
    const userId = req.user?.id;
    const clickedAd = await advertisingService.clickAd(adId, userId!);
    res.json({ status: 200, message: clickedAd });
  } catch (error) {
    next(error);
  }
});

// Update info
router.put(
  "/info/:id",
  verifyAdmin,
  validateContactInfo,
  async (req, res, next) => {
    try {
      const adId = req.params.id;
      const { name, phone, email } = req.body as IContactInfo;
      const { linkTo } = req.body as IAdvertisingInput;
      const updatedAd = await advertisingService.updateContactInfo(
        adId,
        name,
        phone,
        email,
        linkTo
      );
      res.json({ status: 200, message: updatedAd });
    } catch (error) {
      next(error);
    }
  }
);

// Update admin ad control
router.put("/adminAdControl/:id", verifyAdmin, async (req, res, next) => {
  try {
    const adId = req.params.id;
    const { isActive, isApproved, isPaid } = req.body as IAdvertising;
    const updatedAd = await advertisingService.updateAdminAdControl(
      adId,
      isActive,
      isApproved,
      isPaid
    );
    res.json({ status: 200, message: updatedAd });
  } catch (error) {
    next(error);
  }
});

// Delete ad
router.delete("/:id", verifyAdmin, async (req, res, next) => {
  try {
    const adId = req.params.id;
    const deletedAd = await advertisingService.deleteAd(adId);
    res.json({ status: 200, message: deletedAd });
  } catch (error) {
    next(error);
  }
});

export default router;
