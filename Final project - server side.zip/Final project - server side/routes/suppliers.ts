import { Router } from "express"
import { Supplier } from "../db/model/supplier.model"
import { ApplicationError } from "../error/application-error"
import { verifyBusinessUser } from "../middleware/verify-businessUser"
import {
  validateBizNumber,
  validateSupplier,
  validateUpdateSupplier,
  validateUploadImg,
} from "../middleware/validate-schema"
import { verifyRegisteredUser } from "../middleware/verify-registeredUser"
import { ISupplier, ISupplierInput } from "../db/types/db"
import { supplierServices } from "../service/supplier.service"
import { verifyAdmin } from "../middleware/verify-admin"
import { verifyBusinessUserAndSupplier } from "../middleware/verify-supplier"
import { customerInfo } from "../helpers/customer-info"
import { upload } from "../helpers/memoryStorage"
import { BusinessType } from "../db/enum/businessType"
import { Product } from "../db/model/product.model"

const router = Router()

// Get all types of suppliers
router.get("/types", async (req, res, next) => {
  try {
    const supplierTypes = Object.values(BusinessType);
    return res.status(200).json(supplierTypes)
  } catch (e) {
    next(e)
  }
})

// Get all suppliers
router.get("/", async (req, res, next) => {
  try {
    const suppliers = await Supplier.find()
    return res.status(200).json(suppliers);
  } catch (e) { 
    next(e)
  }
})

// Get all suppliers for customer
router.get("/supplierInfo", async (req, res, next) => {
  try {
    const suppliers = (await Supplier.find()) as ISupplier[];
    const supplierInfo = await customerInfo.suppliersObjectInfo(suppliers);
    return res.status(200).json(supplierInfo);
  } catch (e) {
    next(e)
  }
})

// Get all suppliers for business user
router.get("/MyBusinesses", verifyBusinessUser, async (req, res, next) => {
  try {
    const userId = req.user?.id;
    console.log("userId", userId);
    const suppliers = await Supplier.find({ user_id: userId }) as ISupplier[];
    return res.status(200).json(suppliers);
  } catch (e) {
    next(e);
  }
});
 
// Get supplier by id
router.get("/business/:supplierId", async (req, res, next) => {
  try {
    const supplierId = req.params.supplierId;
    const supplier = (await Supplier.findOne({ _id: supplierId })) as ISupplier;
    if (!supplier) {
      throw new ApplicationError(
        `Supplier with id ${req.params.supplierId} not found`,
        404
      );
    }  
    return res.status(200).json( supplier );
  } catch (e) { 
    next(e);
  }
});

// Create supplier
router.post(
  "/",
  verifyBusinessUser,
  validateSupplier,
  async (req, res, next) => {
    try {
      const userId = req.user?.id
      const supplier = await Supplier.create({ ...req.body, user_id: userId })
      return res.status(201).json({massege: "supplier created", supplier})
    } catch (e) {
      next(e)
    }
  }
)

// Update supplier
router.put("/:id", verifyBusinessUserAndSupplier, validateUpdateSupplier, async (req, res, next) => {
  try {
    const supplierId = req.params.id
    const body = req.body as ISupplierInput
    await supplierServices.updateSupplier(supplierId, body)
    const supplier = await Supplier.findById(supplierId)
    return res
      .status(200)
      .json({ message: "Supplier updated", updatedJson: body, supplier })
  } catch (e) { 
    next(e)
  }
})

// Delete supplier
router.delete("/:id", verifyBusinessUserAndSupplier, async (req, res, next) => {
  try {
    const supplierId = req.params.id
    const supplier = await Supplier.findByIdAndDelete(supplierId)
    const supplierProducts = await Product.find({ supplier_id: supplierId })
    if (supplierProducts.length > 0) {
      await Product.deleteMany({ supplier_id: supplierId })
    } 
    if (!supplier) {
      throw new ApplicationError(
        `Supplier with id ${supplierId} not found`,
        404
      )
    }
    return res
      .status(200)
      .json({ message: `Supplier with id ${supplierId} deleted` })
  } catch (e) {
    next(e)
  }
})

// Like or unlike supplier
router.patch("/:id", verifyRegisteredUser, async (req, res, next) => {
  try {
    const supplierId = req.params.id
    const userId = req.user?.id

    const message = await supplierServices.likeOrUnlikeSupplier(
      supplierId,
      userId!
    )
    const supplier = await Supplier.findById(supplierId)
    return res.status(200).json({ message: message })
  } catch (e) {
    next(e)
  }
})

// Change business number
router.patch(
  "/bizNumber/:id",
  verifyAdmin,
  validateBizNumber,
  async (req, res, next) => {
    try {
      const id = req.params.id
      const supplier = await Supplier.findById(id)
      if (!supplier) {
        throw new ApplicationError(`Supplier with id ${id} not found`, 404)
      }
      const bizNum = req.body.bizNumber
      const bizNumUpdated = await supplierServices.changeBizNumber(id, bizNum)
      return res.status(200).json({ message: bizNumUpdated })
    } catch (e) {
      next(e)
    }
  }
)

//upload image
router.post(
  "/uploadImage/:id",
  verifyBusinessUserAndSupplier,
  validateUploadImg,
  upload.single("file"),
  async (req, res, next) => {
    try {
      const supplierId = req.params.id
      const imageUploadObject = {
        file: {
          data: req.file?.buffer,
          contentType: req.file?.mimetype,
        },
        fileName: req.body.fileName,
      }
      const uploadImage = await supplierServices.uploadImg(
        supplierId,
        imageUploadObject
      )
      return res.status(200).json({
        message: "Updated",
      })
    } catch (e) {
      next(e)
    }
  }
)

//delete image
router.delete(
  "/deleteImage/:id",
  verifyBusinessUserAndSupplier,
  async (req, res, next) => {
    try {
      const id = req.params.id
      const uploadImage = await supplierServices.deleteImg(id)
      return res.status(200).json({
        message: "Deleted",
      })
    } catch (e) {
      next(e)
    }
  }
)

export default router
