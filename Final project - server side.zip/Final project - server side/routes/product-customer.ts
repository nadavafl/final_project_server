import { productServices } from "../service/product.service";
import { Router } from "express";
import { verifyRegisteredUser } from "../middleware/verify-registeredUser";

const router = Router();

//Customers:

//Get product by id by customer
router.get("/:id", async (req, res, next) => {
  try {
    const productId = req.params.id;
    const productData = await productServices.getProductInfo(productId);
    return res.status(200).json(productData)
  } catch (e) {
    next(e);
  }
});

//Get all products by customer
router.get("/", async (req, res, next) => {
  try {
    const productsInfo = await productServices.getAllProductsInfo();
    return res.status(200).json(productsInfo);
  } catch (e) {
    next(e);
  }
});

//Ger all products of supplier by supplier id
router.get("/supplierProducts/:id", async (req, res, next) => {
  try {
    const supplierId = req.params.id;
    const productsInfo = await productServices.getAllProductsOfSupplier(supplierId);
    return res.status(200).json(productsInfo);
  } catch (e) {
    next(e);
  }
});

//like or unlike product by customer
router.patch("/:id", verifyRegisteredUser, async (req, res, next) => {
  try {
    const productId = req.params.id;
    const userId = req.user?.id!;
    const message = await productServices.likeOrUnlikeProduct(
      productId,
      userId
    );
    return res.status(200).json({ message: message });
  } catch (e) {
    next(e);
  }
});

export default router;
