import { Router } from "express"
import { productServices } from "./../service/product.service"
import { IImage, IProductInput } from "./../db/types/db.d"
import { Product } from "../db/model/product.model"
import { verifyBusinessUserAndSupplier } from "../middleware/verify-supplier"
import {validateInStock, validateProduct, validateUpdateProduct, validateUploadImg} from "../middleware/validate-schema"
import { upload } from "../helpers/memoryStorage"
import { verifyBusinessUser } from "../middleware/verify-businessUser"

const router = Router()

//Suppliers:

//Create new product
router.post(
  "/:id",
  verifyBusinessUserAndSupplier,
  validateProduct,
  async (req, res, next) => {
    try {
      const supplierId = req.params.id // supplier id
      const body = req.body as IProductInput
      const newProduct = await productServices.newProduct(supplierId, body)
      return res.status(200).json({ message: "Product created", newProduct });
    } catch (e) {
      next(e)
    }
  }
)

//get all products of supplier
router.get(
  "/supplier/myProducts/:id",
  verifyBusinessUserAndSupplier,
  async (req, res, next) => {
    try {
      const supplierId = req.params.id
      const products = await Product.find({ supplier_id: supplierId })
      return res.status(200).json(products)
    } catch (e) {
      next(e)
    }
  }
)

//get product by supplier id
router.get(
  "/supplier/getProduct/:id/:productId",
  verifyBusinessUserAndSupplier,
  async (req, res, next) => {
    try {
      const supplierId = req.params.id
      const productId = req.params.productId
      const product = await Product.find({
        supplier_id: supplierId,
        _id: productId,
      })
      return res.status(200).json(product)
    } catch (e) {
      next(e)
    }
  }
)

//update product by supplier id
router.put(
  "/supplier/updateProduct/:id/:productId",
  verifyBusinessUserAndSupplier,
  validateUpdateProduct,
  async (req, res, next) => {
    try {
      const supplierId = req.params.id
      const productId = req.params.productId
      const body = req.body as IProductInput
      const updatedProduct = await productServices.updateProduct(
        supplierId,
        productId,
        body
      )
      return res.status(200).json({ message: "Product Updated", updatedProduct });
    } catch (e) {
      next(e)
    }
  }
)

//delete product by supplier id
router.delete(
  "/supplier/deleteProduct/:id/:productId",
  verifyBusinessUserAndSupplier,
  async (req, res, next) => {
    try {
      const supplierId = req.params.id
      const productId = req.params.productId
      const message = await productServices.deleteProduct(
        supplierId,
        productId
      )
      return res.status(200).json({ message: message })
    } catch (e) {
      next(e)
    }
  }
)

//inStock update by supplier id and product id
router.patch(
  "/supplier/updateInStock/:id/:productId",
  verifyBusinessUserAndSupplier,
  async (req, res, next) => {
    try {
      const supplierId = req.params.id
      const productId = req.params.productId
      const updatedProduct = await productServices.updateInStock(
        supplierId,
        productId
      )
      return res.status(200).json({ message: "Product Updated", updatedProduct });
    } catch (e) {
      next(e)
    }
  }
)

// Upload image
router.post(
  "/supplier/uploadImage/:id",
  verifyBusinessUser,
  validateUploadImg,
  upload.single("file"),
  async (req, res, next) => {
    try {
      const ProductId = req.params.id;
      const imageUploadObject = <IImage>{
        file: {
          data: req.file?.buffer,
          contentType: req.file?.mimetype,
        },
        fileName: req.body.fileName,
      };
      const uploadImage = await productServices.uploadImg(
        ProductId,
        imageUploadObject
      );
      return res.status(200).json({ message: "Product Updated" });
    } catch (e) {
      next(e);
    }
  }
);

//delete image by and product id and image id
router.delete(
  "/supplier/deleteImage/:id/:imageId",
  verifyBusinessUser,
  async (req, res, next) => {
    try {
      const productId = req.params.id;
      const imageId = req.params.imageId;
      const deletedeImage = await productServices.deleteImg(productId, imageId);
      return res.status(200).json({ message: "Product Updated" });
    } catch (e) {
      next(e);
    }
  }
);

export default router
 