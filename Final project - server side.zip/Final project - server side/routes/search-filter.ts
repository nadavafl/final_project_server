import { Router } from "express"
import { Supplier } from "../db/model/supplier.model"
import { Product } from "../db/model/product.model"
import { searchService } from "../service/search.service"

const router = Router()

// General search
router.get("/", async (req, res, next) => {
  try {
    const query = req.query.q as string
    const searchResults = await searchService.mainSearch(query)
    res.json(searchResults)
  } catch (e) {
    next(e)
  }
})

// Search products in supplier
router.get("/supplier/:id", async (req, res, next) => {
  try {
    const query = req.query.q as string
    const supplierId = req.params.id
    const searchResults = await searchService.searchProducts(query, supplierId)
    res.json(searchResults)
  } catch (e) {
    next(e)
  }
})

// Get in stock products from supplier
router.get("/stock/:id", async (req, res, next) => {
  try {
    const supplierId = req.params.id
    const products = await Product.find({ inStock: true })
    res.json(products)
  } catch (e) {
    next(e)
  }
})

// Get products by price range
router.get("/price", async (req, res, next) => {
  const { min, max } = req.query
  try {
    const products = await Product.find({
      price: { $gte: min, $lte: max },
    })
    res.json(products)
  } catch (e) {
    next(e)
  }
})

// Get products by price from min
router.get("/min-price", async (req, res, next) => {
  try {
    const products = await Product.find().sort({ price: 1 })
    res.json(products)
  } catch (e) {
    next(e)
  }
})

// Get products by price from max
router.get("/max-price", async (req, res, next) => {
  try {
    const products = await Product.find().sort({ price: -1 })
    res.json(products)
  } catch (e) {
    next(e)
  }
})

//get PRODUCTS with most likes
router.get("/products/popularity", async (req, res, next) => {
  try {
    const products = await Product.find().sort({ likes: -1 })
    res.json(products)
  } catch (e) {
    next(e)
  }
})

// Get SUPPLIERS with most likes
router.get("/suppliers/popularity", async (req, res, next) => {
  try {
    const suppliers = await Supplier.find().sort({ likes: -1 })
    res.json(suppliers)
  } catch (e) {
    next(e)
  }
})

export default router
