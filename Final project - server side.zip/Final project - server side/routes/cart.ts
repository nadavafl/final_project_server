import { Router } from "express";
import { cartServices } from "../service/cart.service";
import { ICartItem } from "./../db/types/db.d";
import {
  validateCart,
  validateRemoveItem,
} from "../middleware/validate-schema";
import { verifyBusinessUserAndSupplier } from "../middleware/verify-supplier";
import { verifyUser } from "../middleware/verify-user";
import { verifyCustomerOrSupplier } from "../middleware/verify-customer-supplier";
import { verifyBusinessUser } from "../middleware/verify-businessUser";
import { verifyAdmin } from "../middleware/verify-admin";
import { Cart } from "../db/model/cart.model";

const router = Router();

// Get all carts by admin
router.get("/allCarts", verifyAdmin, async (req, res, next) => {
  try {
    const carts = await Cart.find();
    return res.status(200).json(carts);
  } catch (e) {
    next(e);
  }
});

// Create and update cart
router.post(
  "/add/:id/:supplierId",
  verifyCustomerOrSupplier,
  validateCart,
  async (req, res, next) => {
    try {
      const userId = req.user?.id!;
      const isSupplier = req.user?.isSupplier ?? false;
      const supplierId = req.params.supplierId;
      const body = req.body as ICartItem;
      const addedItem = await cartServices.addItem(
        userId,
        supplierId,
        body,
        isSupplier
      );
      return res.status(200).json({ message: "Cart updated", addedItem });
    } catch (e) {
      next(e);
    }
  }
);

// Remove item from cart
router.post(
  "/remove/:id/:supplierId",
  verifyCustomerOrSupplier,
  validateRemoveItem,
  async (req, res, next) => {
    try {
      const userId = req.user?.id!;
      const supplierId = req.params.supplierId;
      const productId = req.body;
      const removedItem = await cartServices.removeItem(
        userId,
        supplierId,
        productId
      );
      return res
        .status(200)
        .json({ message: "Item removed from cart", removedItem });
    } catch (e) {
      next(e);
    }
  }
);

// Get all carts by USER with user id
router.get("/myCarts/:id", verifyUser, async (req, res, next) => {
  try {
    const userId = req.user?.id!;
    const carts = await cartServices.getAllMyCarts(userId);
    return res.status(200).json(carts);
  } catch (e) {
    next(e);
  }
}); 

// Delete Cart 
router.delete("/delete/:id/:cartId", verifyUser, async (req, res, next) => {
  try {
    const cartId = req.params.cartId;
    const cart = await Cart.findByIdAndDelete(cartId);
    return res.status(200).json({ message: "Cart deleted", cart });
  } catch (e) {
    next(e); 
  }
});


// Delivery approve by SUPPLIER
router.patch(
  "/delivery/:id/:supplierId/:cartId", 
  verifyCustomerOrSupplier,
  async (req, res, next) => {
    try {
      const userId = req.params.id!;
      const supplierId = req.params.supplierId;
      const cartId = req.params.cartId;
      const cart = await cartServices.delivery(userId, supplierId, cartId);
      return res.status(200).json({ message: "Delivery approved", cart });
    } catch (e) {
      next(e);
    }
  }
);    

// Checkout by SUPPLIER
router.patch(
  "/checkout/:id/:supplierId",
  verifyCustomerOrSupplier,
  async (req, res, next) => {
    try {
      const userId = req.user?.id!;
      const supplierId = req.params.supplierId;
      const cart = await cartServices.checkout(userId, supplierId);
      return res.status(200).json({ message: "Paid", cart });
    } catch (e) {
      next(e);
    }
  }
);

//get all carts by SUPPLIER with supplier id.
router.get(
  "/supplierCarts/:supplierId",
  verifyBusinessUser,
  async (req, res, next) => {
    try {
      const supplierId = req.params.supplierId;
      const carts = await cartServices.getCartsBySupplier(supplierId);
      console.log("carts", carts);
      return res.status(200).json({ message: "All carts", carts });
    } catch (e) {
      next(e);
    }
  }
);

// Get cart with user id and supplier id
router.get(
  "/:id/:supplierId",
  verifyCustomerOrSupplier,
  async (req, res, next) => {
    try {
      const userId = req.user?.id!;
      const supplierId = req.params.supplierId;
      const cart = await cartServices.getCart(userId, supplierId);
      return res.status(200).json(cart);
    } catch (e) {
      next(e);
    }
  }
);

// Hide cart by user
router.patch(
  "/hideCart/:id/:invoiceId",
  verifyCustomerOrSupplier,
  async (req, res, next) => {
    try {
      const userId = req.user?.id!;
      // const supplierId = req.params.supplierId;
      const invoiceId = req.params.invoiceId;
      const cart = await cartServices.hideCart(userId, invoiceId);
      return res.status(200).json({ message: "Hidden", cart });
    } catch (e) {
      next(e);
    }
  }
);

export default router;
