import { Router } from "express";
import { ILogin, IUser } from "../db/types/db";
import {
  validateLogin,
  validateUpdateUser,
  validateUpdateUserSchema,
  validateUploadImg,
  validateUser,
} from "../middleware/validate-schema";
import { userServices } from "../service/user.service";
import { User } from "../db/model/user.model";
import { ApplicationError } from "../error/application-error";
import { verifyAdmin } from "../middleware/verify-admin";
import { verifyUser } from "../middleware/verify-user";
import { Supplier } from "../db/model/supplier.model";
import { verifyRegisteredUser } from "../middleware/verify-registeredUser";
// import { upload } from "../helpers/memoryStorage";
import multer from "multer";

const router = Router();

// Create user
router.post("/register", validateUser, async (req, res, next) => {
  try {
    const body = req.body as IUser;
    const savedUser = await userServices.saveUser(body);
    return res.status(201).json({ message: "User created", savedUser });
  } catch (e) {
    next(e);
  }
});

// Login user
router.post("/login", validateLogin, async (req, res, next) => {
  try {
    const { email, password } = req.body as ILogin;
    const token = await userServices.login(email, password);
    return res.status(200).json({ token });
  } catch (e) {
    next(e);
  }
});

// Get all users by admin
router.get("/", verifyAdmin, async (req, res, next) => {
  try {
    const users = await User.find();
    return res.status(200).json(users);
  } catch (e) {
    next(e);
  }
});

// Get user by id
router.get("/:id", verifyUser, async (req, res, next) => {
  try {
    const id = req.user?.id;
    const user = await User.findById(id);
    if (!user) {
      throw new ApplicationError(`User with id ${id} not found`, 404);
    }
    return res.status(200).json(user);
  } catch (e) {
    next(e);
  }
});

// Update user
router.put(
  "/:id",
  verifyUser,
  validateUpdateUserSchema,
  async (req, res, next) => {
    try {
      const id = req.params.id;
      const body = req.body as IUser;
      await userServices.updateUser(id, body);
      const user = await User.findById(id);
      return res
        .status(200)
        .json({ message: "Updatded", updatedJson: body, user });
    } catch (e) {
      next(e);
    }
  }
); 

// Update user role
router.patch("/:id", verifyUser, validateUpdateUser, async (req, res, next) => {
  try {
    const id = req.params.id;
    const body = req.body 
    await userServices.updateRole(id, body);
    const user = await User.findById(id);
    return res
      .status(200)
      .json({ message: "Updatded", updatedJson: body, user });
  } catch (e) {
    next(e);
  }
});

// Delete user
router.delete("/:id", verifyUser, async (req, res, next) => {
  try {
    const id = req.params.id;
    const user = await User.findByIdAndDelete(id);
    if (!user) {
      throw new ApplicationError(`User with id ${id} not found`, 404);
    }
    return res.status(200).json({ message: `User with id ${id} deleted` });
  } catch (e) {
    next(e);
  }
});

// Upload image to user
const upload = multer({ storage: multer.memoryStorage() });
router.post(
  "/uploadImage/:id",
  verifyUser,
  validateUploadImg,
  upload.single("file"),
  async (req, res, next) => {
    try {
      const id = req.params.id;
      const imageUploadObject = {
        file: {
          data: req.file?.buffer,
          contentType: req.file?.mimetype,
        },
        fileName: req.body.fileName,
      };
      console.log("imageUploadObject", req.file);
      const uploadImage = await userServices.uploadImg(id, imageUploadObject);
      return res.status(200).json({
        message: "Updated",
        uploadImage,
      });
    } catch (e) {
      next(e);
    }
  }
);

// Delete user image by user
router.delete("/deleteImage/:id", verifyUser, async (req, res, next) => {
  try {
    const id = req.params.id;
    const uploadImage = await userServices.deleteImg(id);
    return res.status(200).json({
      message: "Deleted",
    });
  } catch (e) {
    next(e);
  }
});

// User favorite supplier
router.patch("/favoriteSupplier/:id", verifyRegisteredUser, async (req, res, next) => {
  try {
    const supplierId = req.params.id;
    const userId = req.user?.id; 

    const message = await userServices.addRemoveFavSupplier(
      supplierId,
      userId!
    );
    const user = await User.findById(userId);
    return res.status(200).json({ message: message });
  } catch (e) {
    next(e);
  }
});

// User favorite product
router.patch("/favoriteProduct/:id", verifyRegisteredUser, async (req, res, next) => {
  try {
    const productId = req.params.id;
    const userId = req.user?.id; 

    const message = await userServices.addRemoveFavProduct(
      productId,
      userId!
    );
    const user = await User.findById(userId);
    return res.status(200).json({ message: message });
  } catch (e) {
    next(e);
  }
});

// Get my businesses (suppliers) - only businessUser
router.get("/my-businesses/:id", verifyUser, async (req, res, next) => {
  try {
    const userId = req.user?.id;
    const suppliers = await Supplier.find({ user_id: userId });
    return res.status(200).json(suppliers);
  } catch (e) {
    next(e);
  }
});

export default router;
