import { Role } from "../db/enum/role"

export type IUpdateUserRole = {
    role: Role.Admin | Role.BusinessUser | Role.Subscriber | Role.Guest
}
     