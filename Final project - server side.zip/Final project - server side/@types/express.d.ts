import { Role } from "../db/enum/role"

export type RequestUser = {
    role: Role
    id: string
    email: string
    isSupplier: boolean
}

declare global {
    namespace Express {
        interface Request {
            user?: RequestUser
        }
    }
}