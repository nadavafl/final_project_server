import { IProduct, ISupplier } from "../db/types/db";

const suppliersObjectInfo = async (suppliers: ISupplier[]) => {
  const suppliersInfo = suppliers.map((supplier) => {
    const suppliersObject = <ISupplier>{
      _id: supplier._id,
      bizNumber: supplier.bizNumber,
      businessType: supplier.businessType,
      title: supplier.title,
      subtitle: supplier.subtitle,
      description: supplier.description,
      phone: supplier.phone,
      email: supplier.email,
      web: supplier.web,
      address: supplier.address,
      image: supplier.image,
      likes: supplier.likes,
      orderDetail: supplier.orderDetail,
    };
    return suppliersObject;
  });
  return suppliersInfo;
};

const productsObjectInfo = async (products: IProduct[]) => {
  const productsInfo = products.map((product) => {
    const productObject = <IProduct>{
      _id: product._id,
      title: product.title,
      description: product.description,
      price: product.price,
      images: product.images,
      product_number: product.product_number,
      likes: product.likes,
      inStock: product.inStock,
      stock: product.stock,
      supplier_id: product.supplier_id,
    };
    return productObject;
  });
  return productsInfo;
};

const supplierObject = async (supplier: ISupplier) => {
  const supplierObject = <ISupplier>{
    businessType: supplier.businessType,
    _id: supplier._id.toString(),
    title: supplier.title,
    subtitle: supplier.subtitle,
    description: supplier.description,
    phone: supplier.phone,
    email: supplier.email,
    web: supplier.web,
    image: supplier.image,
    address: supplier.address,
    orderDetail: supplier.orderDetail,
  };
  return supplierObject;
};

const productObject = async (product: IProduct) => {
  const productObject = <IProduct>{
    _id: product._id?.toString(),
    title: product.title,
    description: product.description,
    price: product.price,
    images: product.images,
    product_number: product.product_number,
    likes: product.likes,
    inStock: product.inStock,
    supplier_id: product.supplier_id,
  };
  return productObject
};

export const customerInfo = {
  suppliersObjectInfo,
  productsObjectInfo,
  supplierObject,
  productObject,
};
