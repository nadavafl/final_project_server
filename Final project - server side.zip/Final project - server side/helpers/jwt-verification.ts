import { RequestUser } from './../@types/express.d'
import { ApplicationError } from "../error/application-error"
import jwt from "jsonwebtoken"

export const jwtVerification = (header: string) => {
     if (!header) {
    throw new ApplicationError("No authorization header", 401)
  }
  const token = header.split(" ")[1]
    const secret = process.env.JWT_SECRET ?? ""
    const payload = jwt.verify(token, secret) as RequestUser
    return payload 
}
