import fs from "fs";
import { Binary } from "mongodb";
import path from "path";

export const productPlaceholderImg = path.join(
  __dirname,
  "../db/default_images",
  "productPlaceholder.jpg"
);

export const supplierPlaceholderImg = path.join(
  __dirname,
  "../db/default_images",
  "supplierPlaceholder.jpg"
);

export const userPlaceholderImg = path.join(
  __dirname,
  "../db/default_images",
  "avatarPlaceholder.png"
);

export const adPlaceholder1 = path.join(
  __dirname,
  "../db/default_images",
  "ad1.jpg",
);

export const adPlaceholder2 = path.join(
  __dirname,
  "../db/default_images",
  "ad2.jpg",
);

export const placeholderImg = (placeholder: string) => {
  const imageBuffer = fs.readFileSync(placeholder);
  const imageToBase64 = imageBuffer.toString("base64");
  return imgFromBase64(imageToBase64);
};

const imgFromBase64 = (placeholder: string) => {
  const image = {
    fileName: "placeholder",
    file: {
      data: Binary.createFromBase64(placeholder),
      contentType: "image/jpeg",
    },
    uploadTime: new Date(),
  };
  return image;
};
