export enum Role {
  Guest = "Guest",
  Subscriber = "Subscriber",
  BusinessUser = "BusinessUser",
  Admin = "Admin",
}