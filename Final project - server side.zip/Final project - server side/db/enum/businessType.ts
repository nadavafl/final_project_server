export enum BusinessType {
    Veg_fruit = "Vegetables & Fruits",
    Bakery = "Bakery",
    Meat_Fish = "Meat & Fish",
    dairy_Confectionery = "Dairy & Confectionery",
    frozen = "Frozen food",
    dry = "Dry food",
    drinks = "Drinks",
    cleaning = "Cleaning products",
    packaging_Disposables = "Packaging & Disposables",
    kitchenware = "Kitchenware",
    workwear = "Workwear",
    other = "Other",
}
