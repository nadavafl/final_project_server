import { model } from "mongoose"
import { roleSchema } from "../schema/role.schema"

const RoleModel = model("Role", roleSchema)

export { RoleModel }