import { model } from "mongoose"
import { cartSchema } from "../schema/cart.schema"

const Cart = model("cart", cartSchema)

export { Cart }