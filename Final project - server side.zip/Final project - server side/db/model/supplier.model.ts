import { model } from "mongoose"
import { supplierSchema } from "../schema/supplier.schema"

const Supplier = model("Supplier", supplierSchema)

export { Supplier } 