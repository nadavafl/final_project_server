import { model } from "mongoose"
import { productSchema } from "../schema/product.schema"

const Product = model("product", productSchema)

export { Product }  