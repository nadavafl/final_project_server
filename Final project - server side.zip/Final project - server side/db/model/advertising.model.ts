import { model } from "mongoose"
import { advertisingSchema } from "../schema/advertising.schema"

const Advertising = model("ads", advertisingSchema)

export { Advertising } 