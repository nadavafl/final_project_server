import { model } from "mongoose"
import { businessTypeSchema } from "../schema/businessType.schema"

const BusinessTypeModel = model("BusinessType", businessTypeSchema)

export { BusinessTypeModel }