import { IAdvertising } from "../types/db";
import { placeholderImg } from "../../helpers/img-placeholder";
import { adPlaceholder1, adPlaceholder2 } from "../../helpers/img-placeholder";
export const initAds: IAdvertising[] = [
  { 
    createdByUser_id: "5f9d88b9e8b4a7fc4445ca9c",
    contactInfo: {
      name: "Danny Davies",
      email: "dave@email.com",
      phone: "050-1234567",
    },
    images: [placeholderImg(adPlaceholder1), placeholderImg(adPlaceholder2)],
    linkTo: "https://www.google.com",
    isPaid: true,
    paidAt: new Date(),
    isApproved: true,
    isActive: true,
    clicks: [],
  },
];
