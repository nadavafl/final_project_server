import { ApplicationError } from "../../error/application-error"
import { Supplier } from "../model/supplier.model"
import { initSuppliers } from "./init-supplier-array"

export const initDBsuppliers = async () => {
  try {
    const count = await Supplier.estimatedDocumentCount();
    if (count !== 0) return;
  } catch (e) {
    console.error(e);
    throw new ApplicationError("Error estimating document count", 500);
  }
  try {
    const productPromises = initSuppliers.map((supplier) =>
      Supplier.create(supplier)
    );
    const suppliers = await Promise.all(productPromises);
    return suppliers;
  } catch (e) {
    console.error(e);
    throw new ApplicationError("Error creating suppliers", 500);
  }
} 