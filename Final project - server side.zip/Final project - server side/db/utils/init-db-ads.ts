import { ApplicationError } from "../../error/application-error"
import { Advertising } from "../model/advertising.model"
import { initAds } from "./init-ad-array"

export const initDBadvertising = async () => {
  try {
    const count = await Advertising.estimatedDocumentCount();
    if (count !== 0) return;
  } catch (e) {}
  try {
    const ads = initAds.forEach(async (ad) => {
      const savedAd = await Advertising.create(ad);
      return savedAd;
    });
  } catch (e) {
    throw new ApplicationError("Error creating ads", 500);
  }
}; 