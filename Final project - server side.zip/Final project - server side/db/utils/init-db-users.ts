import { ApplicationError } from "../../error/application-error"
import { userServices } from "../../service/user.service";
import { User } from "../model/user.model"
import { initUsers } from "./init-user-array"

export const initDBusers = async () => {
  try {
    const count = await User.estimatedDocumentCount();
    if (count !== 0) return;
  } catch (e) {
    console.error(e);
    throw new ApplicationError("Error estimating document count", 500);
  }
  try {
    const userPromises = initUsers.map((user) =>  userServices.saveUser(user));
    const users = await Promise.all(userPromises);
    return users; 
  } catch (e) {
    console.error(e);
    throw new ApplicationError("Error creating users", 500);
  }
}