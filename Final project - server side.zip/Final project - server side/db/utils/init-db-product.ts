import { ApplicationError } from "../../error/application-error"
import { Product } from "../model/product.model"
import { initProducts } from "./init-product-array"

export const initDBproducts = async () => {
  try {
    const count = await Product.estimatedDocumentCount()
    if (count !== 0) return
  } catch (e) {
    console.error(e);
    throw new ApplicationError("Error estimating document count", 500);
  }
  try {
    const productPromises = initProducts.map((product) => Product.create(product));
    const products = await Promise.all(productPromises);
    return products;
  } catch (e) {
    console.error(e);
    throw new ApplicationError("Error creating products", 500);
  }
}