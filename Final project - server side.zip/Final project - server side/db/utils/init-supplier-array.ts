import { ISupplier, ISupplierInput } from "../types/db";
import { placeholderImg } from "../../helpers/img-placeholder";
import { supplierPlaceholderImg } from "../../helpers/img-placeholder";

type Supplier = ISupplier | ISupplierInput;

export const initSuppliers: Supplier[] = [
  {
    _id: "d1fba5444b3d2ccddd2aadf5",
    businessType:
      {
        type: ["Vegetables & Fruits"],
      },
    title: "Vegi & Fruity",
    subtitle: "Fresh fruits and vegetables",
    description:
      "We are a family business that has been operating for 30 years. We are proud to provide our customers with the freshest fruits and vegetables in the market.",
    phone: "050-3211235",
    email: "fruity@gmail.com",
    web: "http://www.vegi-fruity.com",
    image: placeholderImg(supplierPlaceholderImg),
    address: {
      state: "NY",
      country: "USA",
      city: "New York",
      street: "5th Avenue",
      houseNumber: "1",
      postalCode: "8920436",
    },
    orderDetail: {
      minOrder: 100,
      deliveryAreaDays:
        "Sunday/Monday - center, Tuesday/Wednesday - north, Thursday - south",
      deliveryCost: 30,
    },
    likes: ["5f9d88b9e8b4a7ju44fgh54h"],
    bizNumber: 123456789,
    user_id: "65b4e96e94de67fbd82f4ddb", //1
  },
  {
    _id: "5f9d88b9e8b4a7ad44fbb54a",
    businessType: 
      {
        type: ["Vegetables & Fruits"],
      },
    title: "Fresh veggies",
    subtitle: "Fresh vegetables",
    description:
      "From the farm to your table we supply the freshest vegetables in the market.",
    phone: "050-3211236",
    email: "fresh@email.com",
    web: "http://www.fresh-veggies.com",
    image: placeholderImg(supplierPlaceholderImg),
    address: {
      state: "CA",
      country: "USA",
      city: "Los Angeles",
      street: "Hollywood Blvd",
      houseNumber: "2",
      postalCode: "90028",
    },
    orderDetail: {
      minOrder: 200,
      deliveryAreaDays:
        "Sunday/Monday - north, Tuesday/Wednesday - south, Thursday - center",
      deliveryCost: 40,
    },
    likes: ["dsfgs5g44s3d2ssvvd2ssdf5", "5f9d88b9e8b4a7b3efeg18te"],
    bizNumber: 123456788,
    user_id: "5f9d88b9e8b4a7fc4445ca9c", //2
  },
  {
    _id: "5f9d88b9e8bbc7bcdaa54bcb",
    businessType: 
      {
        type: ["Meat & Fish", "Frozen food"],
      },
    title: "Meaty & Fishy",
    subtitle: "Fresh meat and fish",
    description:
      "We are a family business that has been operating for 30 years. We are proud to provide our customers with the freshest meat and fish in the market.",
    phone: "050-3211236",
    email: "meatyfishy@gmail.com",
    web: "http://www.meatyfishy.com",
    image: placeholderImg(supplierPlaceholderImg),
    address: {
      state: "IL",
      country: "Israel",
      city: "Haifa",
      street: "Herzl",
      houseNumber: "2",
      postalCode: "8920437",
    },
    orderDetail: {
      minOrder: 200,
      deliveryAreaDays:
        "Sunday/Monday - north, Tuesday/Wednesday - south, Thursday - center",
      deliveryCost: 40,
    },
    likes: ["5f9d88b9e8b4a7b3efeg18te"],
    bizNumber: 123456787,
    user_id: "65b4e96e94de67fbd82f4ddb", //1
  },
  {
    _id: "5f9d88b9e8b4a7b3efeb18be",
    businessType: 
      {
        type: ["Meat & Fish", "Frozen food"],
      },
    title: "Frozen fish and meat",
    subtitle: "All kinds of frozen fish and meat",
    description: "We supply all kinds of frozen fish and meat.",
    phone: "050-3211237",
    email: "frozen@email.com",
    web: "http://www.frozen.com",
    image: placeholderImg(supplierPlaceholderImg),
    address: {
      state: "AZ",
      country: "USA",
      city: "Phoenix",
      street: "Main St",
      houseNumber: "3",
      postalCode: "75201",
    },
    orderDetail: {
      minOrder: 300,
      deliveryAreaDays:
        "Sunday/Monday - south, Tuesday/Wednesday - center, Thursday - north",
      deliveryCost: 50,
    },
    likes: [],
    bizNumber: 123456786,
    user_id: "5f9d88b9e8b4a7ffee548e2e", //3
  },
  {
    _id: "5f9d88b9e8b4a7b3ebea55b1",
    businessType: 
      {
        type: ["Bakery"],
      },
    title: "Bakery & Dairy",
    subtitle: "Fresh bakery and dairy products",
    description:
      "We are a family business that has been operating for 30 years. We are proud to provide our customers with the freshest bakery in the market.",
    phone: "050-3211237",
    email: "bakery@gmail.com",
    web: "http://www.bakery.com",
    image: placeholderImg(supplierPlaceholderImg),
    address: {
      state: "IL",
      country: "Israel",
      city: "Jerusalem",
      street: "Jaffa",
      houseNumber: "3",
      postalCode: "8920438",
    },
    orderDetail: {
      minOrder: 300,
      deliveryAreaDays:
        "Sunday/Monday - south, Tuesday/Wednesday - center, Thursday - north",
      deliveryCost: 50,
    },
    likes: [
      "5f9d88b9e8b4a7b3efeg18te",
      "5f9d88b9e8b4a7b3etez55ho",
      "5f9d88b9e8b4a7b3e8a1b1a3",
    ],
    bizNumber: 123456785,
    user_id: "5f9d88b9e8b4a7fc4445ca9c", //2
  },
  {
    _id: "5f9d88b9e8b4a7b3e8a1b1a3",
    businessType:
      {
        type: ["Bakery", "Dairy & Confectionery"],
      },
    title: "Bakery",
    subtitle: "Bread and pastries",
    description: "We supply all kinds of bread and pastries.",
    phone: "050-3211238",
    email: "pastries@email.com",
    web: "http://www.pastries.com",
    image: placeholderImg(supplierPlaceholderImg),
    address: {
      state: "CA",
      country: "USA",
      city: "San Francisco",
      street: "Market St",
      houseNumber: "4",
      postalCode: "75202",
    },
    orderDetail: {
      minOrder: 400,
      deliveryAreaDays:
        "Sunday/Monday - center, Tuesday/Wednesday - north, Thursday - south",
      deliveryCost: 60,
    },
    likes: [],
    bizNumber: 123456784,
    user_id: "5f9d88b9e8b4a7ffee548e2e", //3
  },
];
