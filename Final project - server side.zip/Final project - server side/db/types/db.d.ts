import { buffer } from "node:stream/consumers";
import mongoose from "mongoose";

export type IRole = {
  name: string;
};

export type IName = {
  first: string;
  middle: string;
  last: string;
};

export type IAddress = {
  country: string;
  state?: string;
  city: string;
  street: string;
  houseNumber: string;
  postalCode?: string;
};

export type IImage = {
  _id?: mongoose.Types.ObjectId;
  fileName: string;
  file: buffer | string;
  default?: data | string;
  uploadTime?: Date;
};

export interface IFavourites {
  _id: string;
}
export interface IRemoveItem {
  _id: string;
}

export interface IInstock {
  inStock: boolean;
}

export type IUser = {
  role: IRole;
  name: IName;
  phone: string;
  email: string;
  password: string;
  repeatPassword?: string;
  address: IAddress;
  image: IImage;
  favoriteSupplier: object[];
  favoriteProduct: object[];
  _id?: mongoose.Types.ObjectId | string;
};

export type IBusinessType = {
  type: string[];
};

export type IOrderDetail = {
  minOrder: number;
  deliveryAreaDays: string;
  deliveryCost: number;
};

export type ISupplierInput = {
  businessType: IBusinessType;
  title: string;
  subtitle: string;
  description: string;
  phone: string;
  email: string;
  web: string;
  image: IImage;
  address: IAddress;
  orderDetail: IOrderDetail;
};

export type ISupplier = ISupplierInput & {
  _id: mongoose.Types.ObjectId | string;
  bizNumber: number;
  likes: string[];
  user_id: mongoose.Types.ObjectId | string;
  createdAt: Date;
};

export type ILogin = {
  email: string;
  password: string;
};

export type ICartItem = {
  _id: mongoose.Types.ObjectId;
  title: string;
  quantity: number;
  price: number;
};

export type ICartInvoice = {
  _id: mongoose.Types.ObjectId;
  items: ICartItem[];
  total: number;
};

export type ICart = {
  customer_id: mongoose.Types.ObjectId;
  supplier_id: mongoose.Types.ObjectId;
  supplier_name: string;
  items: ICartItem[];
  cartQuantity: number;
  total: number;
  isPaid: boolean;
  paidAt: Date;
  invoice: ICartInvoice;
  isDelivered: boolean;
  deliveredAt: Date;
  hideCart: boolean;
};

export type IProductInput = {
  product_number: string;
  title: string;
  description: string;
  inStock: boolean;
  stock?: number;
  price: number;
  images: IImage[];
};

export type IProduct = IProductInput & {
  _id?: mongoose.Types.ObjectId | string;
  likes: string[];
  supplier_id: mongoose.Types.ObjectId | string;
  createdAt?: Date;
};

export type IContactInfo = {
  name: string;
  phone: string;
  email: string;
};

export type IAdvertisingInput = {
  contactInfo: IContactInfo;
  linkTo: string;
  images: IImage[];
};

export type IAdvertising = IAdvertisingInput & {
  createdByUser_id: mongoose.Types.ObjectId | string;
  clicks: string[];
  isActive: boolean;
  isApproved: boolean;
  isPaid: boolean;
  paidAt: Date;
};
