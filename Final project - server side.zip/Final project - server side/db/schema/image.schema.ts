import { IImage } from './../types/db.d'
import { Schema } from 'mongoose'

export const UploadSchema = new Schema<IImage>({
  fileName: {
    type: String,
    required: false,
  },
  file: {
    data: Buffer || String,
    contentType: String,
  },
  uploadTime: {
    type: Date,
    default: Date.now,
  },
})