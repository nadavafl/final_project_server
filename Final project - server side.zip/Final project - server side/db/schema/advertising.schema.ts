import { Schema } from "mongoose";
import { IAdvertising } from "../types/db";

export const advertisingSchema = new Schema<IAdvertising>(
  {
    createdByUser_id: {
      type: Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    contactInfo: {
      name: {
        type: String,
        required: true,
      },
      phone: {
        type: String,
        required: true,
      },
      email: {
        type: String,
        required: true,
      },
    },
    linkTo: {
      type: String,
      required: false,
    },
    images: [
      {
        fileName: {
          type: String,
          required: false,
        },
        file: {
          data: Buffer || String,
          contentType: String,
        },
        uploadTime: {
          type: Date,
          default: Date.now,
        },
      },
    ],
    clicks: [
      {
        type: Schema.Types.ObjectId,
        ref: "User",
      },
    ],
    isActive: {
      type: Boolean,
      default: false,
    },
    isApproved: {
      type: Boolean,
      default: false,
    },
    isPaid: {
      type: Boolean,
      default: false,
    },
    paidAt: {
      type: Date,
    },
  },
  {
    timestamps: true,
  }
);
