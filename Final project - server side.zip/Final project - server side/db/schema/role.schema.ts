import { Schema } from "mongoose"
import { IRole } from "../types/db"
import { Role } from "../enum/role"

export const roleSchema = new Schema<IRole>({
  name: {
    type: String,
    enum: Object.values(Role),
    required: false,
    default: Role.Guest,
  },
})
