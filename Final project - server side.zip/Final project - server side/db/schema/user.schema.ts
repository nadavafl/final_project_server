import { Schema } from "mongoose"
import { IUser } from "../types/db"
import { UploadSchema } from "./image.schema"
import { roleSchema } from "./role.schema"
import { placeholderImg } from "../../helpers/img-placeholder"
import { userPlaceholderImg } from "../../helpers/img-placeholder"

export const userSchema = new Schema<IUser>(
  {
    role: {
      type: roleSchema,
      ref: "Role",
      required: false,
    },
    name: {
      first: {
        type: String,
        required: true,
        minlength: 2,
        maxlength: 50,
      },
      middle: {
        type: String,
        required: false,
        default: "",
        maxlength: 50,
      },
      last: {
        type: String,
        required: true,
        minlength: 2,
        maxlength: 50,
      },
    },
    phone: {
      type: String,
      required: true,
      unique: true,
      minlength: 9,
      maxlength: 11,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      minlength: 5,
      maxlength: 30,
    },
    password: {
      type: String,
      required: true,
      minlength: 7,
      maxlength: 100,
    },
    address: {
      country: {
        type: String,
        required: true,
        minlength: 2,
        maxlength: 100,
      },
      state: {
        type: String,
        required: false,
        default: "",
        maxlength: 100,
      },
      city: {
        type: String,
        required: true,
        minlength: 2,
        maxlength: 100,
      },
      street: {
        type: String,
        required: true,
        minlength: 2,
        maxlength: 100,
      },
      houseNumber: {
        type: String,
        required: true,
        minlength: 1,
        maxlength: 10,
      },
      postalCode: {
        type: String,
        required: true,
        default: 2,
        maxlength: 10,
      },
    },
    image: {
      type: UploadSchema,
      required: false,
      default: placeholderImg(userPlaceholderImg),
    },
    favoriteSupplier: {
      type: [Object],
      required: false,
      default: [],
    },
    favoriteProduct: {
      type: [Object],
      required: false,
      default: [],
    },
  },
  {
    timestamps: true,
  }
);