import { Schema } from "mongoose"
import { IProduct } from "../types/db"
import { UploadSchema } from "./image.schema"
import { placeholderImg } from "../../helpers/img-placeholder"
import { productPlaceholderImg } from "../../helpers/img-placeholder"

export const productSchema = new Schema<IProduct>(
  {
    product_number: {
      type: String,
      required: true,
      unique: true,
    },
    title: {
      type: String,
      required: true,
      unique: true,
      minlength: 2,
      maxlength: 100,
    },
    description: {
      type: String,
      required: true,
      minlength: 2,
      maxlength: 500,
    },
    inStock: {
      type: Boolean,
      default: true,
      required: true,
    },
    stock: {
      type: Number,
      required: true,
    },
    price: {
      type: Number,
      required: true,
      default: 0,
    },
    supplier_id: {
      type: Schema.Types.ObjectId,
      ref: "Supplier",
      required: true,
    },
    images: {
      type: [UploadSchema],
      required: false,
      default: [placeholderImg(productPlaceholderImg)],
    },
    likes: {
      type: [String],
      required: false,
      default: [],
    },
  },
  {
    timestamps: true,
  }
);