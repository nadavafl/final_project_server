import { Schema } from "mongoose"
import { ICart, ICartInvoice, ICartItem } from "../types/db"
import { round } from "../utils/roundPrice";

const cartItemSchema = new Schema<ICartItem>({
  _id: {
    type: Schema.Types.ObjectId,
    ref: "Product",
  },
  title: {
    type: String,
  },
  quantity: {
    type: Number,
    default: 1,
  },
  price: {
    type: Number,
    set: round,
    get: round
  },
});

const cartInvoiceSchema = new Schema<ICartInvoice>({
  _id: {
    type: Schema.Types.ObjectId,
    ref: "Product",
  },
  items: [cartItemSchema],
  total: {
    type: Number,
    set: round,
    get: round
  },
});

export const cartSchema = new Schema<ICart>(
  {
    customer_id: {
      type: Schema.Types.ObjectId,
      ref: "User",
    },
    supplier_id: {
      type: Schema.Types.ObjectId,
      ref: "Supplier",
    },
    supplier_name: {
      type: String,
    },
    items: [cartItemSchema],
    cartQuantity: {
      type: Number,
      default: 0,
    },
    total: {
      type: Number,
      default: 0,
      set: round,
      get: round,
    },
    isPaid: {
      type: Boolean,
      default: false,
    },
    paidAt: {
      type: Date,
    },
    invoice: cartInvoiceSchema,
    isDelivered: {
      type: Boolean,
      default: false,
    },
    deliveredAt: {
      type: Date,
    },
    hideCart: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
    toObject: { getters: true }, // apply getters when calling toObject
    toJSON: { getters: true }, // apply getters when calling toJSON
  }
);
