import { Schema } from "mongoose";
import { ISupplier } from "../types/db";
import { businessTypeSchema } from "./businessType.schema";
import { placeholderImg } from "../../helpers/img-placeholder";
import { supplierPlaceholderImg } from "../../helpers/img-placeholder";
import { UploadSchema } from "./image.schema";

export const supplierSchema = new Schema<ISupplier>(
  {
    businessType: {
      type: businessTypeSchema, 
      ref: "BusinessType",
      required: true,
    },
    title: {
      type: String,
      required: true,
      minlength: 2,
      maxlength: 150,
    },
    subtitle: {
      type: String,
      required: true,
      minlength: 2,
      maxlength: 150,
    },
    description: {
      type: String,
      required: true,
      minlength: 2,
      maxlength: 2000,
    },
    phone: {
      type: String,
      required: true,
      minlength: 9,
      maxlength: 11,
    },
    email: {
      type: String,
      required: true,
      minlength: 5,
      maxlength: 30,
    },
    web: {
      type: String,
      required: false,
      minlength: 14,
      maxlength: 100,
    },
    address: {
      country: {
        type: String,
        required: true,
        minlength: 2,
        maxlength: 100,
      },
      state: {
        type: String,
        required: false,
        default: "",
        maxlength: 100,
      },
      city: {
        type: String,
        required: true,
        minlength: 2,
        maxlength: 100,
      },
      street: {
        type: String,
        required: true,
        minlength: 2,
        maxlength: 100,
      },
      houseNumber: {
        type: String,
        required: true,
        minlength: 1,
        maxlength: 10,
      },
      postalCode: {
        type: String,
        required: true,
        default: 2,
        maxlength: 10,
      },
    },
    bizNumber: {
      type: Number,
      unique: true,
      required: false,
      default: () => Math.floor(Math.random() * 1000000000),
      minlength: 9,
      maxlength: 11,
    },
    likes: {
      type: [String],
      required: false,
      default: [],
    },
    user_id: {
      type: Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    image: {
      type: UploadSchema,
      required: false,
      default: placeholderImg(supplierPlaceholderImg),
    },
    orderDetail: {
      minOrder: {
        type: Number,
        required: false,
        min: 0,
      },
      deliveryAreaDays: {
        type: String,
        required: false,
        minlength: 2,
        maxlength: 100,
      },
      deliveryCost: {
        type: Number,
        required: false,
        min: 0,
      },
    },
  },
  {
    timestamps: true,
  }
);
