import { Schema } from "mongoose"
import { IBusinessType } from "../types/db"
import { BusinessType } from "../enum/businessType"

export const businessTypeSchema = new Schema<IBusinessType>({
  type: {
    type: [String],
    enum: Object.values(BusinessType),
    required: true,
  },
})