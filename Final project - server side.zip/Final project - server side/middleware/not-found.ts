import { RequestHandler } from "express"
import path from "path"

export const notFound: RequestHandler = (req, res, next) => {
    res.status(404).sendFile(path.join(__dirname, "../public/404.html"))
}  