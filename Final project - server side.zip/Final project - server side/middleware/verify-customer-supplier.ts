import { RequestHandler } from "express";
import { ApplicationError } from "../error/application-error";
import { Supplier } from "../db/model/supplier.model";
import { jwtVerification } from "../helpers/jwt-verification";

export const verifyCustomerOrSupplier: RequestHandler = async (
  req,
  res,
  next
) => {
  const header = req.headers.authorization;

  try {
    req.user = jwtVerification(header as string);

    if (req.user?.role === "Admin") return next();

    if (req.user?.id === req.params.id) return next();

    if (req.user.role === "BusinessUser") {
      const id = req.params.supplierId;
      const supplier = await Supplier.findOne({ _id: id });

      if (!supplier) throw new ApplicationError("Supplier not found", 404);

      //update cart by supplier
      if (supplier.user_id.toString() === req.user.id) {
        req.user.isSupplier = true;
        return next();
      }
    }

    throw new ApplicationError("Not authorized!!!", 401);
  } catch (e) {
    next(e);
  }
};
