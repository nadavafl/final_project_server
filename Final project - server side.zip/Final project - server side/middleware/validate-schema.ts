import { RequestHandler } from "express";
import Joi from "joi";
import { joiUserSchema } from "../validators/user.joi";
import { joiSupplierSchema } from "../validators/supplier.joi";
import { joiLoginSchima } from "../validators/login.joi";
import { joiUpdateRole } from "../validators/update-role.joi";
import { joiBizNumberSchema } from "../validators/biz-number.joi";
import { joiUploadImgSchema } from "../validators/upload-img.joi";
import { joiProductSchema } from "../validators/product.joi";
import { joiCartSchema } from "../validators/cart.joi";
import { joiInStockSchema } from "../validators/in-stock.joi";
import { joiRemoveItemSchema } from "../validators/remove-item.joi";
import { joiUpdateSupplierSchema } from "../validators/supplier-update.joi";
import { joiUpdateProductSchema } from "../validators/product-update.joi";
import { joiUpdateUserSchema } from "../validators/user-update.joi";
import { joiUploadAdSchema } from "../validators/upload-ad.joi";
import { joiContactInfoSchema } from "../validators/contact-info.joi";

type ValidateSchema = (schema: Joi.ObjectSchema) => RequestHandler;

const validateSchema: ValidateSchema = (schema) => async (req, res, next) => {
  try {
    await schema.validateAsync(req.body);
    next();
  } catch (e) {
    return res.status(400).json(e);
  }
};

export const validateUser = validateSchema(joiUserSchema);
export const validateLogin = validateSchema(joiLoginSchima);
export const validateSupplier = validateSchema(joiSupplierSchema);
export const validateUpdateUser = validateSchema(joiUpdateRole);
export const validateBizNumber = validateSchema(joiBizNumberSchema);
export const validateUploadImg = validateSchema(joiUploadImgSchema);
export const validateProduct = validateSchema(joiProductSchema);
export const validateCart = validateSchema(joiCartSchema);
export const validateInStock = validateSchema(joiInStockSchema);
export const validateRemoveItem = validateSchema(joiRemoveItemSchema);
export const validateUpdateSupplier = validateSchema(joiUpdateSupplierSchema);
export const validateUpdateProduct = validateSchema(joiUpdateProductSchema);
export const validateUpdateUserSchema = validateSchema(joiUpdateUserSchema);
export const validateUploadAd = validateSchema(joiUploadAdSchema);
export const validateContactInfo = validateSchema(joiContactInfoSchema);
