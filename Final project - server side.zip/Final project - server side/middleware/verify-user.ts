import { RequestHandler } from "express";
import { ApplicationError } from "../error/application-error";
import { jwtVerification } from "../helpers/jwt-verification";

export const verifyUser: RequestHandler = async (req, res, next) => {
  const header = req.headers.authorization;

  try {
    req.user = jwtVerification(header as string);

    if (req.user?.id === req.params.id) return next();

    if (req.user?.role === "Admin") return next();

    throw new ApplicationError("Not authorized", 401);
  } catch (e) {
    next(e);
  }
};
