import { RequestHandler } from "express";
import { ApplicationError } from "../error/application-error";
import { jwtVerification } from "../helpers/jwt-verification";

export const verifyRegisteredUser: RequestHandler = async (req, res, next) => {
  const header = req.headers.authorization;

  try {
    req.user = jwtVerification(header as string);

    if (req.user?.role !== "Guest") return next();

    throw new ApplicationError("Not authorized. Please register", 401);
  } catch (e) {
    next(e);
  }
};
