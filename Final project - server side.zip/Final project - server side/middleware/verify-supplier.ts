import { RequestHandler } from "express";
import { ApplicationError } from "../error/application-error";
import { Supplier } from "../db/model/supplier.model";
import { jwtVerification } from "../helpers/jwt-verification";

export const verifyBusinessUserAndSupplier: RequestHandler = async (
  req,
  res,
  next
) => {
  const header = req.headers.authorization;
  try {
    req.user = jwtVerification(header as string);

    if (req.user.role === "Admin") return next();

    if (req.user.role === "BusinessUser") {
      const id = req.params.id;
     
      const supplier = await Supplier.findOne({ _id: id });

      if (!supplier) throw new ApplicationError("Supplier not found", 404);

      if (supplier.user_id.toString() === req.user.id) return next();
    }
    throw new ApplicationError("Not authorized", 401);
  } catch (e) {
    next(e);
  }
};
