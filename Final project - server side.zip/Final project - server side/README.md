# Getting Started with node server App

## Installation

Enter the server folder

```bash
cd final project- server side
```

Install the node_modules

```bash
pnpm i
```

## Available Scripts

you can run:

### `pnpm start:windows`

- It will run the app with node
- The page will not reload if you make edits.
- You must have a mongoDB Atlas Cluster

### `pnpm watch:windows`

- Runs the app with nodemon
- The page will reload if you make edits
- The print at the terminal will be purple with the message:

`Listening on: http://localhost:8080`

And if there are no login errors you should see the message in bold:

`connected to MongoDb`

## Available Routes

Here you can find API addresses that the server will respond to as well as what should be sent to them in the body of the HTTP request and what permissions are required to receive a response from a specific API

### Users API

#### API for Register a new user

```http
  POST /api/v1/users
```

#### Request

In the request body you will need to provide an object with the following keys and values

| index      | type    | index       | type   | min | max | remark   |
| ---------- | ------- | ----------- | ------ | --- | --- | -------- |
| role       | object  |             |        |     |     | required |
|            |         | Guest       |string  |     |     |          |
|            |         | Subscriber  |string  |     |     |          |
|            |         | BusinessUser|string  |     |     |          |
|            |         | Admin       |string  |     |     |          |
| name       | object  |             |        |     |     | required |
|            |         | first       | string | 2   | 50  | required |
|            |         | middle      | string |     | 50  |          |
|            |         | last        | string | 2   | 50  | required |
| phone      | string  |             |        | 9   | 11  | required |
| email      | string  |             |        | 5   | 30  | required |
| password   | string  |             |        | 7   | 20  | required |
| address    | object  |             |        |     |     | required |
|            |         | state       | string | 2   | 100 |          |
|            |         | country     | string | 2   | 100 | required |
|            |         | city        | string | 2   | 100 | required |
|            |         | street      | string | 2   | 100 | required |
|            |         | houseNumber | string | 1   | 10  | required |
|            |         | postalCode  | string | 1   | 10  |          |

- "password" must be at least nine characters long and contain an uppercase letter, a lowercase letter, a number and one of the following characters !@#$%^&\*-
- "phone" must be a standard Israeli phone number
- "email" must be a standard email


### API for Upload image

```http
  POST /api/v1/users/uploadImage/:id
```

| index  | type   | index   | type   | index      | type      | min | max | remark |      
| image  | object |         |        |            |           |     |     |        |
|        |        | fileName| string |            |           |  1  | 30  |        |
|        |        | file    | object |            | string    |     |     |required|
|        |        |         |        | data       | binary    |     |     |required|
|        |        |         |        | contentType| image/jpeg|     |     |required|

### Request

- You will need to provide a token to get an answer from this api
- You will need to be the registered user or Admin type user to get an answer from this api



#### API for Login a user

```http
  POST /api/v1/users/login
```

### Request

In the request body you will need to provide an object with the following keys and values

| index    | type   | min | max | remark   |
| -------- | ------ | --- | --- | -------- |
| email    | string | 5   | 30  | required |
| password | string | 7   | 20  | required |

- "email" must be a standard email
- "password" must be at least nine characters long and contain an uppercase letter, a lowercase letter, a number and one of the following characters !@#$%^&\*-


### Response

If the user is in the database and the password sent is correct, a token will be returned and the following object can be extracted from it with the help of the jwt-decode library

| index      | type    |
| ---------- | ------- |
| _id        | string  |
| role       | string  |
| email      | string  |

#### API for Information about all the users

```http
  GET /api/v1/users
```

### Request

- You will need to provide a token to get an answer from this api
- You will need to be Admin type user to get an answer from this api

#### API for Information about a user

```http
  GET /api/v1/users/:id
```

### Request

- You will need to provide a token to get an answer from this api
- You will need to be the registered user or Admin type user to get an answer from this api

#### API for Updating User information

```http
  PUT /api/v1/users/:id
```

### Request

In the request body you will need to provide an object with the following keys and values

| index      | type    | index       | type   | min | max | remark   |
| ---------- | ------- | ----------- | ------ | --- | --- | -------- |
| role       | object  |             |        |     |     | required |
|            |         | Guest       |string  |     |     |          |
|            |         | Subscriber  |string  |     |     |          |
|            |         | BusinessUser|string  |     |     |          |
|            |         | Admin       |string  |     |     |          |
| name       | object  |             |        |     |     | required |
|            |         | first       | string | 2   | 50  | required |
|            |         | middle      | string |     | 50  |          |
|            |         | last        | string | 2   | 50  | required |
| phone      | string  |             |        | 9   | 11  | required |
| email      | string  |             |        | 5   | 30  | required |
| password   | string  |             |        | 7   | 20  | required |
| address    | object  |             |        |     |     | required |
|            |         | state       | string | 2   | 100 |          |
|            |         | country     | string | 2   | 100 | required |
|            |         | city        | string | 2   | 100 | required |
|            |         | street      | string | 2   | 100 | required |
|            |         | houseNumber | string | 1   | 10  | required |
|            |         | postalCode  | string | 1   | 10  |          |

- The user "password" must be at least nine characters long and contain an uppercase letter, a lowercase letter, a number and one of the following characters !@#$%^&\*-
- "phone" must be a standard Israeli phone number
- "email" must be a standard email
- You will need to provide a token to get an answer from this api
- You will need to be the registered user or Admin to get an answer from this api


#### API for deleting a user

```http
  DELETE /api/v1/users/:id
```

- You will need to provide a token to get an answer from this api
- You will need to be the registered user or Admin to get an answer from this api

### API to delete image

```http
  DELETE /api/v1/users/deleteImage/:id
```
- You will need to provide a token to get an answer from this api
- You will need to be the registered user or Admin to get an answer from this api


### API to add / remove from favorites

```http
  PATCH /api/v1/users/favorites/:id
```

- You will need to provide a token to get an answer from this api
- You will need to be the registered user or Admin to get an answer from this api


### API to Get my businesses (suppliers) - only businessUser
```http
  GET /api/v1/users/my-businesses/:id
```

- You will need to provide a token to get an answer from this api
- You will need to be the business user or Admin to get an answer from this api

#### Suppliers API

### API to get all business suppliers

```http
  GET /api/v1/suppliers/
```

#### API for get a business supplier of a specific business

```http
  GET /api/v1/suppliers/:id
```

- You will need to provide a token to get an answer from this api
- You will need to be the business user or Admin to get an answer from this api

#### API for create a new business supplier

```http
  POST /api/v1/suppliers/
```

### Request

In the request body you will need to provide an object with the following keys and values

| index       | type   | index       | type   | min | max  | remark   |
| ----------- | ------ | ----------- | ------ | --- | ---- | -------- |
| businessType| string |             |        |     |      | required |
| title       | string |             |        | 2   | 150  | required |
| subtitle    | string |             |        | 2   | 150  | required |
| description | string |             |        | 2   | 2000 | required |
| phone       | string |             |        | 9   | 11   | required |
| email       | string |             |        | 5   | 30   | required |
| web         | string |             |        | 14  | 100  | required |
| address     | object |             |        |     |      | required |
|             |        | state       | string | 2   | 100  |          |
|             |        | country     | string | 2   | 100  | required |
|             |        | city        | string | 2   | 100  | required |
|             |        | street      | string | 2   | 100  | required |
|             |        | houseNumber | string | 1   | 10   | required |
|             |        | postalCode  | string | 2   | 10   |          |
| orderDetail | object |             |        |     |      | required |
|             |        | minOrder    | number | 1   |      | required |
|             |        | deliveryCost| number | 0   |      | required |
|             |        | deliAreaDays| string | 2   | 100  | required |

- "phone" must be a standard Israeli phone number
- "email" must be a standard email
- "web" must be a standard URL
- You will need to provide a token to get an answer from this api
- You will need to be a Business type user to get an answer from this api


### API for Upload image

```http
  POST /api/v1/suppliers/uploadImage/:id
```

| index  | type   | index   | type   | index      | type      | min | max | remark |      
| image  | object |         |        |            |           |     |     |        |
|        |        | fileName| string |            |           |  1  | 30  |        |
|        |        | file    | object |            | string    |     |     |required|
|        |        |         |        | data       | binary    |     |     |required|
|        |        |         |        | contentType| image/jpeg|     |     |required|

### Request

- You will need to provide a token to get an answer from this api
- You will need to be the registered user or Admin type user to get an answer from this api


#### API for updating business supplier information

```http
  PUT /api/v1/suppliers/:id
```

### Request

In the request body you will need to provide an object with the following keys and values

| index       | type   | index       | type   | min | max  | remark   |
| ----------- | ------ | ----------- | ------ | --- | ---- | -------- |
| businessType| string |             |        |     |      | required |
| title       | string |             |        | 2   | 150  | required |
| subtitle    | string |             |        | 2   | 150  | required |
| description | string |             |        | 2   | 2000 | required |
| phone       | string |             |        | 9   | 11   | required |
| email       | string |             |        | 5   | 30   | required |
| web         | string |             |        | 14  | 100  | required |
| address     | object |             |        |     |      | required |
|             |        | state       | string | 2   | 100  |          |
|             |        | country     | string | 2   | 100  | required |
|             |        | city        | string | 2   | 100  | required |
|             |        | street      | string | 2   | 100  | required |
|             |        | houseNumber | string | 1   | 10   | required |
|             |        | postalCode  | string | 2   | 10   |          |
| orderDetail | object |             |        |     |      | required |
|             |        | minOrder    | number | 1   |      | required |
|             |        | deliveryCost| number | 0   |      | required |
|             |        | deliAreaDays| string | 2   | 100  | required |

- "phone" must be a standard Israeli phone number
- "email" must be a standard email
- "web" must be a standard URL
- You will need to provide a token to get an answer from this api
- You will need to be a Business type user to get an answer from this api


### API to delete image

```http
  DELETE /api/v1/suppliers/deleteImage/:id
```
- You will need to provide a token to get an answer from this api
- You will need to be the registered user or Admin to get an answer from this api


#### API for liking a business supplier

```http
	PATCH /api/v1/suppliers/:id
```

- You will need to provide a token to get an answer from this api

#### API for changing the business number

```http
	PATCH /api/v1/suppliers/biz-number/:id
```

### Request

In the request body you will need to provide an object with the following keys and values

| index     | type   | min | max | remark   | from    | to      |
| --------- | ------ | --- | --- | -------- | ------- | ------- |
| bizNumber | number | 7   | 7   | required | 1000000 | 9999999 |

- You will need to provide a token to get an answer from this api
- You will need to be an admin type user to get an answer from this api

#### API for deleting a business supplier

```http
  DELETE /api/v1/suppliers/:id
```

- You will need to provide a token to get an answer from this api
- You must be the user who created the supplier or an admin in order to delete the business supplier
