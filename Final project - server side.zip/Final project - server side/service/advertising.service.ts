import { Advertising } from "../db/model/advertising.model";
import { IAdvertising, IContactInfo, IImage } from "../db/types/db";
import { ApplicationError } from "../error/application-error";

const postAd = async (
  userId: string,
  advertisingUploadObject: IAdvertising,
  imageUploadObject: IImage
) => {
  const uploadUser = await Advertising.findOne({ "createdByUser_id": userId });
  const imageFile: IImage[] = advertisingUploadObject.images;

  console.log("imageFile", imageFile);
  console.log("uploadUser", uploadUser);

  if (!uploadUser) {
    const newAd = new Advertising(advertisingUploadObject);
    await newAd.save();
    return `New ad created`;
  } else if (uploadUser.images.length < 4) {
    uploadUser.images.push(imageUploadObject);
    await uploadUser.save();
    return `Ad updated`;
  }

  throw new ApplicationError("You can only upload 4 images", 400);
};

const deleteImgAd = async (adId: string, fileId: string) => {
  const Ad = await Advertising.findOne({ _id: adId });
  if (!Ad) {
    throw new ApplicationError("Ad not found", 404);
  }
  const deletedImage = Ad.images.filter(
    (image) => image._id?.toString() != fileId
  );
  Ad.images = deletedImage;
  await Ad.save();
  return `Image deleted`;
};

const clickAd = async (adId: string, userId: string) => {
  const Ad = await Advertising.findById(adId);
  if (!Ad) {
    throw new ApplicationError("Ad not found", 404);
  }
  const clickedAd = Ad.clicks.push(userId);
  await Ad.save();
  return `Ad clicked`;
};

const updateContactInfo = async (
  adId: string,
  name: string,
  phone: string,
  email: string,
  linkTo: string
) => {
  const Ad = await Advertising.findById(adId);
  if (!Ad) {
    throw new ApplicationError("Ad not found", 404);
  }
  if (name) Ad.contactInfo.name = name;
  if (phone) Ad.contactInfo.phone = phone;
  if (email) Ad.contactInfo.email = email;
  if (linkTo) Ad.linkTo = linkTo;

  await Ad.save();
  return `Contact info updated`;
};

const updateAdminAdControl = async (
  adId: string,
  isActive: boolean,
  isApproved: boolean,
  isPaid: boolean
) => {
  const Ad = await Advertising.findById(adId);
  if (!Ad) {
    throw new ApplicationError("Ad not found", 404);
  }

  if (isActive !== undefined) Ad.isActive = isActive;
  if (isApproved !== undefined) Ad.isApproved = isApproved;
  if (isPaid !== undefined) Ad.isPaid = isPaid;

  await Ad.save();
  return `Ad updated`;
};

const deleteAd = async (adId: string) => {
  const deletedAd = await Advertising.findByIdAndDelete(adId);
  return `Ad deleted`;
};

export const advertisingService = {
  postAd,
  deleteImgAd,
  clickAd,
  updateContactInfo,
  updateAdminAdControl,
  deleteAd,
};
