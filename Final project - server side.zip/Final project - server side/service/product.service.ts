import { Product } from "../db/model/product.model";
import { Supplier } from "../db/model/supplier.model";
import { IImage, IProduct, IProductInput } from "../db/types/db";
import { ApplicationError } from "../error/application-error";
import { customerInfo } from "../helpers/customer-info";
import { placeholderImg } from "../helpers/img-placeholder";
import { productPlaceholderImg } from "../helpers/img-placeholder";

const newProduct = async (id: string, body: IProductInput) => {
  const newProduct = new Product({
    supplier_id: id,
    product_number: body.product_number,
    title: body.title,
    description: body.description,
    price: body.price,
    inStock: body.inStock,
    stock: body.stock,
  });
  await newProduct.save();  
};

const getProductInfo = async (id: string) => {
  const product = (await Product.find({ _id: id })) as IProduct[];
  if (!product) {
    throw new ApplicationError("Product not found", 404);
  }
  const productInfo = customerInfo.productsObjectInfo(product);
  return productInfo;
};

const getAllProductsInfo = async () => {
  const products = (await Product.find()) as IProduct[];
  if (!products) {
    throw new ApplicationError("Products not found", 404);
  }

  const productsInfo = customerInfo.productsObjectInfo(products);
  return productsInfo;
};

const getAllProductsOfSupplier = async (id: string) => {
  const products = (await Product.find({ supplier_id: id })) as IProduct[];
  if (!products) {
    throw new ApplicationError("Products not found", 404);
  }
  const productsInfo = customerInfo.productsObjectInfo(products);
  return productsInfo;
}

const updateProduct = async (
  supplierId: string,
  productId: string,
  reqBody: IProductInput
) => {
  const product = await Product.findById(productId);
  if (!product) {
    throw new ApplicationError("Product not found", 404);
  }
  if (product.supplier_id.toString() !== supplierId) {
    throw new ApplicationError("Not authorized", 401);
  }
  const body = reqBody as Partial<IProductInput>;

  if (body.product_number) product.product_number = body.product_number;
  if (body.title) product.title = body.title;
  if (body.description) product.description = body.description;
  if (body.price) product.price = body.price;
  if (body.stock) product.stock = body.stock;
  const updatedProduct = await product.save();
  return updatedProduct;
};

const deleteProduct = async (supplierId: string, productId: string) => {
  const product = await Product.findById(productId);
  if (!product) {
    throw new ApplicationError("Product not found", 404);
  }
  if (product.supplier_id.toString() !== supplierId) {
    throw new ApplicationError("Not authorized", 401);
  }
  await product.deleteOne();
  return "Product deleted";
};

const likeOrUnlikeProduct = async (productId: string, userId: string) => {
  const product = await Product.findById(productId);
  if (!product) {
    throw new ApplicationError("Product not found", 404);
  }
  if (product?.likes.includes(userId)) {
    await Product.findByIdAndUpdate(
      productId,
      { $pull: { likes: userId } },
      { new: true }
    );
    return "Like removed";
  }
  await Product.findByIdAndUpdate(
    productId,
    { $push: { likes: userId } },
    { new: true }
  );
  return "Like added";
};

const updateInStock = async (
  supplierId: string,
  productId: string,
) => {
  const product = await Product.findById(productId);
  if (!product) {
    throw new ApplicationError("Product not found", 404);
  }
  if (product.supplier_id.toString() !== supplierId) {
    throw new ApplicationError("Not authorized", 401);
  }
  product.inStock = !product.inStock; 
  const updatedProduct = await product.save();
  return updatedProduct;
};

const uploadImg = async (prductId: string, imageUploadObject: IImage) => {
  const product = await Product.findById(prductId);
  if (!product) {
    throw new ApplicationError("Product not found", 404);
  } 

  const supplier = await Supplier.findById(product.supplier_id);
  if (product.supplier_id.toString() !== supplier?._id.toString()) {
    throw new ApplicationError("Not authorized", 401);
  }

  if (product.images.length <= 3) {
    const newImage: IImage = {
      fileName: imageUploadObject.fileName,
      file: imageUploadObject.file,
      uploadTime: imageUploadObject.uploadTime,
    };

    const placeholderIndex = product.images.findIndex(
      (image) => image.fileName === "placeholder"
    );
    if (placeholderIndex !== -1) {
      product.images[placeholderIndex] = newImage;
    } else {
      product.images.push(newImage);
    }

    const updatedProduct = await product.save();
    return updatedProduct;
  } else {
    throw new ApplicationError("You can upload only 3 images", 400);
  }
};

const deleteImg = async (prductId: string, imageId: string) => {
  console.log("prductId", prductId, "imageId", imageId)
  const product = await Product.findById(prductId);
  if (!product) {
    throw new ApplicationError("Product not found", 404); 
  }

  const supplier = await Supplier.findById(product.supplier_id);
  if (product.supplier_id.toString() !== supplier?._id.toString()) {
    throw new ApplicationError("Not authorized", 401);
  }

  const imageExists = product.images?.some((image) => image._id?.toString() === imageId);

  if (!imageExists) { 
    throw new ApplicationError("Image not found", 404);
  }

  product.images = product.images?.filter((image) => image._id?.toString() !== imageId) || [];

  const placeholder = placeholderImg(productPlaceholderImg);
  product.images = product.images.length === 0 ? [placeholder] : product.images;
  const updatedProduct = await product.save();
  return updatedProduct;
};

export const productServices = {
  newProduct,
  getProductInfo,
  getAllProductsInfo,
  getAllProductsOfSupplier,
  updateProduct,
  deleteProduct,
  likeOrUnlikeProduct,
  updateInStock,
  uploadImg,
  deleteImg,
};
