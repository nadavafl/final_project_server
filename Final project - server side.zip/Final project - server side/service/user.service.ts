import jwt from "jsonwebtoken";
import { User } from "../db/model/user.model";
import { IFavourites, IUser } from "../db/types/db";
import bcrypt from "bcrypt";
import { ApplicationError } from "../error/application-error";
import { Supplier } from "../db/model/supplier.model";
import { placeholderImg } from "../helpers/img-placeholder";
import { userPlaceholderImg } from "../helpers/img-placeholder";
import { customerInfo } from "../helpers/customer-info";
import { Product } from "../db/model/product.model";

const saveUser = async (userData: IUser) => { 
  const userEmail = await User.findOne({ email: userData.email });
  const userPhone = await User.findOne({ phone: userData.phone });
  if (userEmail) {
    throw new ApplicationError("Email already exists", 400);
  }
  if (userPhone) {
    throw new ApplicationError("Phone number already exists", 400);
  }
  const user = new User(userData);
  user.password = await bcrypt.hash(user.password, 12);
  const savedUser = await user.save();
  return savedUser; 
};

const getSecret = () => process.env.JWT_SECRET ?? "secret";

const login = async (email: string, password: string) => {
  const user = await User.findOne({ email });
  if (!user) {
    throw new ApplicationError("Email or password dont match", 401);
  }
  const match = await bcrypt.compare(password, user.password);
  if (!match) {
    throw new ApplicationError("Email or password dont match", 401);
  }
  const token = jwt.sign({ id: user._id, role: user.role.name }, getSecret());
  return token;
};

const updateUser = async (id: string, reqBody: IUser) => {
  const user = await User.findById(id);

  if (!user) throw new ApplicationError(`User with id ${id} not found`, 404);

  const body = reqBody as Partial<IUser>;

  if (body.image) user.image = body.image;
  if (body.phone) user.phone = body.phone;
   if (body.password) {
     if (body.password !== body.repeatPassword) {
       throw new ApplicationError(
         "Password and confirm password dont match",
         400
       ); 
     }
     const hashedPassword = await bcrypt.hash(body.password, 12);
     user.password = hashedPassword;
   }
  if (body.address) {
    if (body.address.country) user.address.country = body.address.country;
    if (body.address.state) user.address.state = body.address.state;
    if (body.address.city) user.address.city = body.address.city;
    if (body.address.street) user.address.street = body.address.street;
    if (body.address.houseNumber)
      user.address.houseNumber = body.address.houseNumber;
    if (body.address.postalCode)
      user.address.postalCode = body.address.postalCode;
  }
  if (body.name) {
    if (body.name.first) user.name.first = body.name.first;
    if (body.name.middle) user.name.middle = body.name.middle;
    if (body.name.last) user.name.last = body.name.last;
  }

  const updatedUser = await user.save();

  if (!updatedUser)
    throw new ApplicationError(`Error updating user with id ${id}`, 500);

  return updatedUser;
};

const updateRole = async (id: string, role: string) => {
  const user = await User.findById(id);
  if (!user) throw new ApplicationError(`User with id ${id} not found`, 404);

  const body = role as Partial<IUser>;

  if (body.role) {
    user.role.name = body.role.name;
  }
   const updatedUser = await user.save();

   if (!updatedUser)
     throw new ApplicationError(`Error updating user with id ${id}`, 500);

   return updatedUser;
};

const uploadImg = async (id: string, imageUploadObject: object) => {
  const user = await User.findById(id);
  if (!user) {
    throw new ApplicationError(`User with id ${id} not found`, 404);
  }
  const updatedUser = await User.findByIdAndUpdate(
    id,
    { image: imageUploadObject },
    { new: true }
  );
  if (!updatedUser) {
    throw new ApplicationError(`Error updating user with id ${id}`, 500);
  }
  return updatedUser; 
};


const deleteImg = async (id: string) => {
  const user = await User.findById(id);
  if (!user) {
    throw new ApplicationError(`User with id ${id} not found`, 404);
  }

  const placeholder = placeholderImg(userPlaceholderImg);

  user.image = placeholder;
  const updatedUser = await user.save();
  if (!updatedUser) {
    throw new ApplicationError(`Error updating user with id ${id}`, 500);
  }
  return updatedUser;
};

const addRemoveFavSupplier = async (supplierId: string, userId: string) => {
  const user = await User.findById(userId);
  if (!user)
    throw new ApplicationError(`User with id ${userId} not found`, 404);

  const supplier = await Supplier.findById(supplierId);
  if (!supplier)
    throw new ApplicationError(`Supplier with id ${supplierId} not found`, 404);

  const supplierIdString = supplier?._id.toString();
  const supplierObject = await customerInfo.supplierObject(supplier)

  if (
    (user?.favoriteSupplier as IFavourites[]).find(
      (f) => f._id === supplierIdString
    )
  ) {
    await User.findByIdAndUpdate(
      userId,
      { $pull: { favoriteSupplier: supplierObject } },
      { new: true }
    );
    return "Supplier removed from favorites";
  }
  await User.findByIdAndUpdate(
    userId,
    { $push: { favoriteSupplier: supplierObject } },
    { new: true }
  );
  return "Supplier added to favorites";
};

const addRemoveFavProduct = async (productId: string, userId: string) => {
  const user = await User.findById(userId);
  if (!user)
    throw new ApplicationError(`User with id ${userId} not found`, 404);

  const product = await Product.findById(productId);
  if (!product)
    throw new ApplicationError(`Product with id ${productId} not found`, 404);

  const productIdString = product?._id.toString();
  const productObject = await customerInfo.productObject(product);

  if (
    (user?.favoriteProduct as IFavourites[]).find((f) => f._id === productIdString)
  ) {
    await User.findByIdAndUpdate(
      userId,
      { $pull: { favoriteProduct: productObject } },
      { new: true }
    );
    return "Product removed from favorites";
  }
  await User.findByIdAndUpdate(
    userId,
    { $push: { favoriteProduct: productObject } },
    { new: true }
  );
  return "Product added to favorites";
}

export const userServices = {
  saveUser,
  login,
  updateUser,
  updateRole,
  uploadImg,
  deleteImg,
  addRemoveFavSupplier,
  addRemoveFavProduct,
};
