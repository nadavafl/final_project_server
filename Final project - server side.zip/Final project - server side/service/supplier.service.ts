import { ISupplierInput } from "../db/types/db";
import { ApplicationError } from "../error/application-error";
import { Supplier } from "../db/model/supplier.model";
import { placeholderImg } from "../helpers/img-placeholder";
import { supplierPlaceholderImg } from "../helpers/img-placeholder";
import { Product } from "../db/model/product.model";

const updateSupplier = async (id: string, reqBody: ISupplierInput) => {
  const supplier = await Supplier.findById(id);

  if (!supplier)
    throw new ApplicationError(`Supplier with id ${id} not found`, 404);

  const body = reqBody as Partial<ISupplierInput>;

  if (body.businessType) supplier.businessType = body.businessType;
  if (body.title) supplier.title = body.title;
  if (body.subtitle) supplier.subtitle = body.subtitle;
  if (body.description) supplier.description = body.description;
  if (body.phone) supplier.phone = body.phone;
  if (body.email) supplier.email = body.email;
  if (body.web) supplier.web = body.web;
  if (body.address) {
    if (body.address.country) supplier.address.country = body.address.country;
    if (body.address.state) supplier.address.state = body.address.state;
    if (body.address.city) supplier.address.city = body.address.city;
    if (body.address.street) supplier.address.street = body.address.street;
    if (body.address.houseNumber)
      supplier.address.houseNumber = body.address.houseNumber;
    if (body.address.postalCode)
      supplier.address.postalCode = body.address.postalCode;
  }
  if (body.orderDetail) {
    if (body.orderDetail.minOrder)
      supplier.orderDetail.minOrder = body.orderDetail.minOrder;
    if (body.orderDetail.deliveryAreaDays)
      supplier.orderDetail.deliveryAreaDays = body.orderDetail.deliveryAreaDays;
    if (body.orderDetail.deliveryCost)
      supplier.orderDetail.deliveryCost = body.orderDetail.deliveryCost;
  }

  const updatedSupplier = await supplier.save();

  if (!updatedSupplier)
    throw new ApplicationError(`Error updating supplier with id ${id}`, 500);

  return updatedSupplier;
};

const likeOrUnlikeSupplier = async (supplierId: string, userId: string) => {
  const supplier = await Supplier.findById(supplierId);
  if (!supplier)
    throw new ApplicationError(`Supplier with id ${supplierId} not found`, 404);

  if (supplier?.likes.includes(userId)) {
    await Supplier.findByIdAndUpdate(
      supplierId,
      { $pull: { likes: userId } },
      { new: true }
    );
    return "Like removed";
  }
  await Supplier.findByIdAndUpdate(
    supplierId,
    { $push: { likes: userId } },
    { new: true }
  );
  return "Like added";
};

const changeBizNumber = async (supplierId: string, bizNum: number) => {
  const allSuppliers = await Supplier.find();

  if (allSuppliers.map((supplier) => supplier.bizNumber !== bizNum)) {
    await Supplier.findByIdAndUpdate(
      supplierId,
      { $set: { bizNumber: bizNum } },
      { new: true }
    );
    return `biz-supplier of supplier with id ${supplierId} updated`;
  }
  throw new ApplicationError(
    `biz-supplier of supplier with id ${supplierId} already exists`,
    400
  );
};

const uploadImg = async (id: string, imageUploadObject: object) => {
  const supplier = await Supplier.findById(id);
  if (!supplier) {
    throw new ApplicationError(`Supplier with id ${id} not found`, 404);
  }
  const updatedSupplier = await Supplier.findByIdAndUpdate(
    id,
    { image: imageUploadObject },
    { new: true }
  );
  if (!updatedSupplier) {
    throw new ApplicationError(`Error updating supplier with id ${id}`, 500);
  }
  return updatedSupplier;
};

const deleteImg = async (id: string) => {
  const supplier = await Supplier.findById(id);
  if (!supplier) {
    throw new ApplicationError(`Supplier with id ${id} not found`, 404);
  }

  const placeholder = placeholderImg(supplierPlaceholderImg);

  supplier.image = placeholder;
  const updatedSupplier = await supplier.save();
  if (!updatedSupplier) {
    throw new ApplicationError(`Error updating supplier with id ${id}`, 500);
  }
  return updatedSupplier;
};

const deleteSupplier = async (id: string) => { 
  const supplier = await Supplier.findByIdAndDelete(id);
  const supplierProducts = await Product.find({ supplier_id: id });
  if (supplierProducts.length > 0) {
    await Product.deleteMany({ supplier_id: id });
  }
  if (!supplier) {
    throw new ApplicationError(`Supplier with id ${id} not found`, 404); 
  }
  return `Supplier with id ${id} deleted`;   
}

export const supplierServices = { 
  updateSupplier,
  likeOrUnlikeSupplier,
  changeBizNumber,
  uploadImg,
  deleteImg,
  deleteSupplier,
};
