import { BusinessType } from "../db/enum/businessType"
import { Product } from "../db/model/product.model"
import { Supplier } from "../db/model/supplier.model"
import { IProduct, ISupplier } from "../db/types/db"
import { ApplicationError } from "../error/application-error"
import { customerInfo } from "../helpers/customer-info"

const mainSearch = async (query: string) => {
  let conditions: object[] = [] 
  if (query) {
    if (query.startsWith('"') && query.endsWith('"')) {
      //search exact phrase
      const phrase = query.slice(1, -1)
      conditions.push(
        { title: new RegExp(`\\b${phrase}\\b`, "i") },
        { subtitle: new RegExp(`\\b${phrase}\\b`, "i") },
        { description: new RegExp(`\\b${phrase}\\b`, "i") },
        { phone: new RegExp(`\\b${phrase}\\b`, "i") },
        { email: new RegExp(`\\b${phrase}\\b`, "i") },
        { web: new RegExp(`\\b${phrase}\\b`, "i") },
        { "address.country": new RegExp(`\\b${phrase}\\b`, "i") },
        { "address.state": new RegExp(`\\b${phrase}\\b`, "i") },
        { "address.city": new RegExp(`\\b${phrase}\\b`, "i") },
        { "address.street": new RegExp(`\\b${phrase}\\b`, "i") }
      )
    } else {
      // search for each word
      const words = query.trim().split(/\s+/).filter(Boolean)
      words.forEach((word) => {
        conditions.push(
          { title: new RegExp(word, "i") },
          { subtitle: new RegExp(word, "i") },
          { description: new RegExp(word, "i") },
          { phone: new RegExp(word, "i") },
          { email: new RegExp(word, "i") },
          { web: new RegExp(word, "i") },
          { "address.country": new RegExp(word, "i") },
          { "address.state": new RegExp(word, "i") },
          { "address.city": new RegExp(word, "i") },
          { "address.street": new RegExp(word, "i") }
        )
      })
    }
  } else {
    throw new ApplicationError("No search query provided", 400)
  }
  const words = query.trim().split(/\s+/).filter(Boolean)
  const regex = new RegExp(words.join("|"), "i")
  const businessTypes = Object.values(BusinessType)
  const categories = businessTypes.filter((type) => regex.test(type))
  const suppliers = (await Supplier.find({ $or: conditions })) as ISupplier[]
  const suppliersInfo = await customerInfo.suppliersObjectInfo(suppliers)
  const products = (await Product.find({ $or: conditions })) as IProduct[]
  const productsInfo = await customerInfo.productsObjectInfo(products)
  return { categories, suppliersInfo, productsInfo }
}
 
const searchProducts = async (query: string, supplierId: string) => {
  let conditions: object[] = []
  if (query) {
    if (query.startsWith('"') && query.endsWith('"')) {
      const phrase = query.slice(1, -1)
      conditions = [
        { title: new RegExp(`\\b${phrase}\\b`, "i") },
        { description: new RegExp(`\\b${phrase}\\b`, "i") },
        { product_number: new RegExp(`\\b${phrase}\\b`, "i") },
      ]
    } else {
      const words = query.trim().split(/\s+/).filter(Boolean)
      conditions = words.map((word) => ({
        $or: [
          { title: new RegExp(word, "i") },
          { description: new RegExp(word, "i") },
          { product_number: new RegExp(word, "i") },
          { price: Number(word) },
        ],
      }))
    }
  } else {
    throw new ApplicationError("No search query provided", 400)
  }
  const products = (await Product.find({
    $and: [{ supplier_id: supplierId }, { $or: conditions }],
  })) as IProduct[]
  const productsInfo = await customerInfo.productsObjectInfo(products)
  return productsInfo
}

export const searchService = { mainSearch, searchProducts }
