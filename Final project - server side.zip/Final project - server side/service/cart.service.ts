import { Cart } from "../db/model/cart.model";
import { Product } from "../db/model/product.model";
import { Supplier } from "../db/model/supplier.model";
import { ApplicationError } from "../error/application-error";
import { ICartItem } from "./../db/types/db.d";

const addItem = async (
  userId: string,
  supplierId: string,
  product: ICartItem,
  isSupplier: boolean
) => {
  const cart = await Cart.findOne({
    customer_id: userId,
    supplier_id: supplierId,
    isPaid: false,
  });
  const getproductInfo = async (_id: string) => {
    const productName = (await Product.findById(_id).select("title")) as {
      title: string;
    };
    const productPrice = await Product.findById(_id).select("price");
    const productSum = ((productPrice?.price ?? 0) *
      product.quantity) as number;
    const productInfo = { productName, productSum, productPrice };
    return productInfo;
  };
  const getSupplierInfo = async (_id: string) => {
    const supplierName = (await Supplier.findById(_id).select("title")) as {
      title: string;
    };
    console.log("supplierName", supplierName.title);
    return supplierName;
  };

  if (!cart) {
    if (product.quantity < 0 || product.price < 0) {
      throw new ApplicationError("Invalid quantity or price", 400);
    }
    const newCart = new Cart({
      customer_id: userId,
      supplier_id: supplierId,
      supplier_name: (await getSupplierInfo(supplierId)).title,
      items: {
        _id: product._id,
        title: (await getproductInfo(product._id as any)).productName?.title,
        quantity: product.quantity,
        price: isSupplier
          ? product.price
          : (await getproductInfo(product._id as any)).productPrice?.price,
      },
      cartQuantity: 1,
      total: isSupplier
        ? product.price
        : (await getproductInfo(product._id as any)).productSum,
    });
    await newCart.save();
  } else {
    const item = cart.items.find(
      (item) => item._id == product._id
    ) as ICartItem;
    if (!item) {
      if (product.quantity < 0 || product.price < 0) {
        throw new ApplicationError("Invalid quantity or price", 400);
      }
      cart.items.push({
        _id: product._id,
        quantity: product.quantity,
        price: isSupplier
          ? product.price
          : (await getproductInfo(product._id as any)).productPrice?.price ?? 0,
        title: (await getproductInfo(product._id as any)).productName?.title,
      });
      cart.cartQuantity += 1;
      cart.total += isSupplier
        ? product.price
        : (await getproductInfo(product._id as any)).productSum;
    } else if (
      item.quantity + product.quantity >= 0 &&
      item.price + (await getproductInfo(product._id as any)).productSum >= 0
    ) {
      item.quantity += product.quantity;
      (item.price = isSupplier
        ? product.price
        : (await getproductInfo(product._id as any)).productPrice?.price ?? 0),
        (cart.total += isSupplier
          ? product.price
          : (await getproductInfo(product._id as any)).productSum);
      if (item.quantity === 0) {
        cart.items = cart.items.filter((item) => item._id != product._id);
        cart.cartQuantity -= 1;
      }
    } else {
      throw new ApplicationError("Invalid quantity or price", 400);
    }
    await cart.save();
     if (cart.items.length === 0) {
       await cart.deleteOne();
     }
  }
};

const removeItem = async (
  userId: string,
  supplierId: string,
  product: ICartItem
) => {
  const cart = await Cart.findOne({
    customer_id: userId,
    supplier_id: supplierId,
    isPaid: false,
  });
  if (!cart) {
    throw new ApplicationError("Cart not found", 404);
  }
  const itemId = cart.items.find((item) => item._id == product._id);
  if (!itemId) {
    throw new ApplicationError("Item not found", 404);
  }
  cart.items = cart.items.filter((item) => item._id != product._id);
  cart.cartQuantity -= 1;
  cart.total -= itemId.price;

  await cart.save();
  if (cart.items.length === 0) {
    await cart.deleteOne();
  }
};

const getAllMyCarts = async (userId: string) => {
  const carts = await Cart.find({ customer_id: userId });
  if (!carts) {
    throw new ApplicationError("Carts not found", 404);
  }
  const paidCarts = carts.filter((cart) => cart.isPaid);
  const unpaidCarts = carts.filter((cart) => !cart.isPaid);
  const allCarts = { paidCarts, unpaidCarts };
  return allCarts;
};

const getCart = async (userId: string, supplierId: string) => {
  const cart = await Cart.findOne({
    customer_id: userId,
    supplier_id: supplierId,
  });
  if (!cart) {
    throw new ApplicationError("Cart not found", 404);
  }
  return cart;
};

const delivery = async (userId: string, supplierId: string, cartId: string) => {
  const cart = await Cart.findOne({
    supplier_id: supplierId,
    customer_id: userId,
    _id: cartId,
  });
  if (!cart) {
    throw new ApplicationError("Cart not found", 404);
  }
  cart.isDelivered = true;
  cart.deliveredAt = new Date(); 
  await cart.save();
  return cart;
};

const checkout = async (userId: string, supplierId: string) => {
  const cart = await Cart.findOne({
    customer_id: userId,
    supplier_id: supplierId,
    isPaid: false,
  });
  if (!cart) {
    throw new ApplicationError("Cart not found", 404);
  }
  cart.isPaid = true;
  cart.invoice = {
    _id: cart._id,
    items: cart.items,
    total: cart.total,
  };
  cart.paidAt = new Date();
  cart.items = [];
  cart.cartQuantity = 0;
  cart.total = 0;
  await cart.save();
  return cart;
};

const getCartsBySupplier = async (supplierId: string) => {
  const carts = await Cart.find({ supplier_id: supplierId });
  if (!carts) {
    throw new ApplicationError("Carts not found", 404);
  }
  return carts;
};

const hideCart = async (userId: string, invoiceId: string) => {
  const cart = await Cart.findOne({
    customer_id: userId,
    "invoice._id": invoiceId,
  });
  if (!cart) {
    throw new ApplicationError("Cart not found", 404);
  }
  cart.hideCart = true;
  await cart.save();
  return cart;
};

export const cartServices = {
  addItem,
  removeItem,
  getCart,
  getAllMyCarts,
  checkout,
  delivery,
  getCartsBySupplier,
  hideCart,
};
