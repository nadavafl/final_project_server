import express from "express"
import { connect } from "./db/utils/connection"
import usersRouter from "./routes/users"
import suppliersRouter from "./routes/suppliers"
import { logger } from "./middleware/logger"
import { errorHandler } from "./middleware/error-handler"
import { configEnv } from "./environment"
import cors from "cors"
import chalk from "chalk"
import { notFound } from "./middleware/not-found"
import { initDBusers } from "./db/utils/init-db-users"
import { initDBsuppliers } from "./db/utils/init-db-suppliers"
import bodyParser from "body-parser"
import commercialRouter from "./routes/advertising"
import cartRouter from "./routes/cart"
import productCustomerRouter from "./routes/product-customer"
import productSupplierRouter from "./routes/product-supplier"
import searchBarRouter from "./routes/search-filter"
import { initDBproducts } from "./db/utils/init-db-product"
import { initDBadvertising } from "./db/utils/init-db-ads"

configEnv()
connect()
initDBusers()
initDBsuppliers()
initDBproducts()
initDBadvertising()
 
const app = express()

const reactPort = process.env.REACT_PORT

app.use(
  cors({
    origin: `http://localhost:${reactPort}`,
  })
)

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
app.use(express.json())
app.use(logger)

app.use(express.static("public"))

app.use("/api/v1/users", usersRouter)
app.use("/api/v1/suppliers", suppliersRouter)  
app.use("/api/v1/upload", commercialRouter)
app.use("/api/v1/cart", cartRouter)
app.use("/api/v1/product", productCustomerRouter)
app.use("/api/v1/product", productSupplierRouter)
app.use("/api/v1/search", searchBarRouter)

app.use(errorHandler)

app.use(notFound)

const PORT = process.env.EXPRESS_PORT

app.listen(PORT, () => {
  console.log(
    chalk.bold.underline.blue(`App is running on http://localhost:${PORT}`)
  )
})
