import joi from "joi";
import { IInstock } from "../db/types/db";

export const joiInStockSchema = joi.object<IInstock>({
  inStock: joi.boolean().required().default(true),
});
