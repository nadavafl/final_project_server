import joi from "joi";
import { IProductInput } from "../db/types/db";

export const joiProductSchema = joi.object<IProductInput>({
  product_number: joi.string().required(),
  title: joi.string().min(2).max(100).required(),
  description: joi.string().min(2).max(500).required(),
  stock: joi.number(),
  inStock: joi.boolean().required(),
  price: joi.number().required(),
});
