import Joi from "joi";
import { IImage } from "../db/types/db";

export const joiUploadImgSchema = Joi.object<IImage>({
  fileName: Joi.string().min(1).max(30),
  file: {
    data: Joi.binary().required(),
    contentType: Joi.string().required(),
  },
});
