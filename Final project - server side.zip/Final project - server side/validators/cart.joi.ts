import joi from 'joi'
import { ICartItem } from '../db/types/db'

export const joiCartSchema = joi.object<ICartItem>({
    _id: joi.string().required(),
    quantity: joi.number().required(),
    price: joi.number(),
})