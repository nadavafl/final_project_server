import joi from "joi";
import { IUser, IAddress, IName, IRole } from "./../db/types/db.d";
import { patterns } from "./regex-patterns";
import { Role } from "../db/enum/role";

export const joiUserSchema = joi.object<IUser>({
  role: joi.object<IRole>({
    name: joi
      .string()
      .valid(...Object.values(Role))
      .required(),
  }),
  email: joi.string().email().required().min(5).max(30),
  password: joi
    .string()
    .required()
    .min(7)
    .max(20)
    .pattern(new RegExp(patterns.password)),
  phone: joi
    .string()
    .required()
    .min(9)
    .max(11)
    .pattern(new RegExp(patterns.phone)),
  name: joi.object<IName>({
    first: joi.string().min(2).max(50).required(),
    middle: joi.string().min(0).max(50),
    last: joi.string().min(2).max(50).required(),
  }),
  address: joi.object<IAddress>({
    country: joi.string().min(2).max(100).required(),
    state: joi.string().min(0).max(100),
    city: joi.string().min(2).max(100).required(),
    street: joi.string().min(2).max(100).required(),
    houseNumber: joi.string().min(1).max(10).required(),
    postalCode: joi.string().min(1).max(10),
  }),
});
