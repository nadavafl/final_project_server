import Joi from "joi"
import { ISupplier } from "../db/types/db"

export const joiBizNumberSchema = Joi.object<ISupplier>({
    bizNumber: Joi.number().greater(99999999).less(99999999999).required(),
}) 