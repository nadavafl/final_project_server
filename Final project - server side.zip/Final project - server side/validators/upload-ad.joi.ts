import joi from "joi";
import { IAdvertisingInput, IContactInfo, IImage } from "../db/types/db";
import { patterns } from "./regex-patterns";

export const joiUploadAdSchema = joi.object<IAdvertisingInput>({
  images: joi.array().items(
    joi.object<IImage>({
      fileName: joi.string().min(1).max(30),
      file: {
        data: joi.binary().required(),
        contentType: joi.string().required(),
      },
    })
  ),
  linkTo: joi.string().uri(),
  contactInfo: joi.object<IContactInfo>({
    name: joi.string().min(2).max(30).required(),
    phone: joi
      .string()
      .required()
      .min(9)
      .max(11)
      .pattern(new RegExp(patterns.phone)),
    email: joi.string().email().required(),
  }),
});
