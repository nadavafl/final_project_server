import joi from "joi";
import {
  IAddress,
  IBusinessType,
  IOrderDetail,
  ISupplierInput,
} from "../db/types/db";
import { patterns } from "./regex-patterns";
import { BusinessType } from "../db/enum/businessType";

export const joiSupplierSchema = joi.object<ISupplierInput>({
  businessType: joi
    .object({
      type: joi.array().items(
        joi
          .string()
          .valid(...Object.values(BusinessType))
          .required()
      ),
    })
    .required(),
  title: joi.string().min(2).max(150).required(),
  subtitle: joi.string().min(2).max(150).required(),
  description: joi.string().min(2).max(2000).required(),
  phone: joi
    .string()
    .required()
    .min(9)
    .max(11)
    .pattern(new RegExp(patterns.phone)),
  email: joi.string().required().min(5).max(30).email(),
  web: joi.string().min(5).max(100).uri(),
  address: joi.object<IAddress>({
    country: joi.string().min(2).max(100).required(),
    state: joi.string().min(0).max(100),
    city: joi.string().min(2).max(100).required(),
    street: joi.string().min(2).max(100).required(),
    houseNumber: joi.string().min(1).max(10).required(),
    postalCode: joi.string().min(2).max(10),
  }),
  orderDetail: joi.object<IOrderDetail>({
    minOrder: joi.number().min(1),
    deliveryAreaDays: joi.string().min(2).max(100),
    deliveryCost: joi.number().min(0),
  }),
});
