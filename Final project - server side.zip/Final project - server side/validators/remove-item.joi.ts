import joi from 'joi'
import { IRemoveItem } from '../db/types/db'

export const joiRemoveItemSchema = joi.object<IRemoveItem>({
    _id: joi.string().required(),
})