import joi from "joi";
import { IProductInput } from "../db/types/db";

export const joiUpdateProductSchema = joi.object<IProductInput>({
  product_number: joi.number(),
  title: joi.string().min(2).max(100),
  description: joi.string().min(2).max(500),
  stock: joi.number(),
  inStock: joi.boolean(),
  price: joi.number(),
});
