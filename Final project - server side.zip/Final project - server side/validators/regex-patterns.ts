export const passwordPattern =
  /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&äÄöÖüÜß]).{8,}$/

export const phonePattern =
  /^((\+972|0)(-)?([23489]|5[02345678]|77)(-)?[1-9]\d{6})$/

export const patterns = { password: passwordPattern, phone: phonePattern }
 