import joi from "joi";
import { IUser, IAddress, IName, IRole } from "./../db/types/db.d";
import { patterns } from "./regex-patterns";
import { Role } from "../db/enum/role";

export const joiUpdateUserSchema = joi.object<IUser>({
  role: joi.object<IRole>({
    name: joi.string().valid(...Object.values(Role)),
  }),
  email: joi.string().email().min(5).max(30),
  password: joi
    .string()
    .min(7)
    .max(20)
    .pattern(new RegExp(patterns.password)),
  repeatPassword: joi.any()
    .valid(joi.ref("password"))
    .options({
      messages: { "any.only": "Password and confirm password dont match" },
    }),
  phone: joi
    .string()

    .min(9)
    .max(11)
    .pattern(new RegExp(patterns.phone)),
  name: joi.object<IName>({
    first: joi.string().min(2).max(50),
    middle: joi.string().min(0).max(50),
    last: joi.string().min(2).max(50),
  }),
  address: joi.object<IAddress>({
    country: joi.string().min(2).max(100),
    state: joi.string().min(2).max(100),
    city: joi.string().min(2).max(100),
    street: joi.string().min(2).max(100),
    houseNumber: joi.string().min(1).max(10),
    postalCode: joi.string().min(1).max(10),
  }),
});
