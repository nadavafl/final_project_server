import { IAdvertisingInput } from "./../db/types/db.d";
import joi from "joi";
import { IContactInfo } from "../db/types/db";
import { patterns } from "./regex-patterns";

type info = IContactInfo & IAdvertisingInput;

export const joiContactInfoSchema = joi.object<info>({
  name: joi.string().min(2).max(30),
  phone: joi.string().min(9).max(11).pattern(new RegExp(patterns.phone)),
  email: joi.string().email(),
  linkTo: joi.string().uri(),
});
