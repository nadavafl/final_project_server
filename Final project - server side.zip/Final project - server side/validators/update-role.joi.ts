import joi from "joi";
import { IUpdateUserRole } from "../@types/updateUser";

export const joiUpdateRole = joi.object<IUpdateUserRole>({
  role: joi
    .object({
      name: joi
        .string()
        .valid("BusinessUser", "Subscriber", "Guest")
        .required(),
    })
    .required(),
});
